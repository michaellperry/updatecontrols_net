using System.Collections.Generic;
using System.Linq;
using UpdateControls.Fields;

namespace HierarchicalOptions.Models
{
    public class OptionLeaf : Option
    {
        private Independent<bool> _selected = new Independent<bool>();
        private decimal _itemPrice;

        public OptionLeaf(string name, decimal itemPrice)
            : base(name)
        {
            _itemPrice = itemPrice;
        }

        public override bool? IsChecked
        {
            get { return _selected; }
            set { _selected.Value = value ?? false; }
        }

        public override IEnumerable<Option> Children
        {
            get { return Enumerable.Empty<Option>(); }
        }

        public override IEnumerable<string> CheckedItems
        {
            get
            {
                if (_selected)
                    yield return Name;
            }
        }

        public override decimal Price
        {
            get
            {
                if (_selected)
                    return _itemPrice;
                else
                    return 0.00m;
            }
        }
    }
}
