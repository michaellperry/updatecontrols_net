﻿using System.Collections.Generic;

namespace HierarchicalOptions.Models
{
    public abstract class Option
    {
        private string _name;

        public Option(string name)
        {
            _name = name;
        }

        public string Name
        {
		    get { return _name; }
        }

        public abstract bool? IsChecked { get; set; }
        public abstract IEnumerable<Option> Children { get; }
        public abstract IEnumerable<string> CheckedItems { get; }
        public abstract decimal Price { get; }
    }
}
