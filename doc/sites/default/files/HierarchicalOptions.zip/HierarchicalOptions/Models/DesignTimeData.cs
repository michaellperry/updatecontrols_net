﻿
namespace HierarchicalOptions.Models
{
    public class DesignTimeData
    {
        public Option Root
        {
            get
            {
                return new OptionGroup("All options", 999.95m)
                    .Add(new OptionGroup("Basic options", 59.95m)
                        .Add(new OptionLeaf("Floor mats", 49.95m))
                        .Add(new OptionLeaf("Passenger vanity mirror", 23.95m))
                    )
                    .Add(new OptionGroup("Deluxe options", 475.95m)
                        .Add(new OptionLeaf("Chrome wheels", 245.95m))
                        .Add(new OptionLeaf("Driver vanity mirror", 34.95m))
                        .Add(new OptionGroup("Performance package", 249.95m)
                            .Add(new OptionLeaf("Fuel injection", 145.95m))
                            .Add(new OptionLeaf("Anti-lock breaks", 175.95m))
                        )
                    )
                    .Add(new OptionGroup("Luxury options", 645.95m)
                        .Add(new OptionLeaf("Leather seats", 345.95m))
                        .Add(new OptionLeaf("Leather steering wheel cover", 125.95m))
                        .Add(new OptionLeaf("Wood panel interior", 275.95m))
                    );
            }
        }
    }
}
