using System.Collections.Generic;
using System.Linq;

namespace HierarchicalOptions.Models
{
    public class OptionGroup : Option
    {
        private List<Option> _children = new List<Option>();
        private decimal _packagePrice;
        
        public OptionGroup(string name, decimal packagePrice)
            : base(name)
        {
            _packagePrice = packagePrice;
        }

        public OptionGroup Add(Option child)
        {
            _children.Add(child);
            return this;
        }

        public override bool? IsChecked
        {
            get
            {
                bool allChecked = _children.All(child => child.IsChecked == true);
                bool allNotChecked = _children.All(child => child.IsChecked == false);

                if (allNotChecked)
                    return false;
                else if (allChecked)
                    return true;
                else
                    return null;
            }
            set
            {
                foreach (var child in _children)
                    child.IsChecked = value ?? false;
            }
        }

        public override IEnumerable<Option> Children
        {
            get { return _children; }
        }

        public override IEnumerable<string> CheckedItems
        {
            get
            {
                if (IsChecked == true)
                    return Enumerable.Repeat(Name, 1);
                else
                    return Children.SelectMany(child => child.CheckedItems);
            }
        }

        public override decimal Price
        {
            get
            {
                if (IsChecked == true)
                    return _packagePrice;
                else
                    return Children.Sum(child => child.Price);
            }
        }
    }
}
