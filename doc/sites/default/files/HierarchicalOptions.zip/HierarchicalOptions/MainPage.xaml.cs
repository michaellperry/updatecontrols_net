﻿using System.Windows;
using System.Windows.Controls;
using HierarchicalOptions.Models;
using UpdateControls.XAML;

namespace HierarchicalOptions
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            DataContext = ForView.Wrap(new DesignTimeData().Root);
        }
    }
}
