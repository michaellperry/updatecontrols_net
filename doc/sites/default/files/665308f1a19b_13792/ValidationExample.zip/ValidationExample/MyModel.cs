using System.Text.RegularExpressions;
using UpdateControls.Fields;

namespace ValidationExample
{
    public class MyModel
    {
        private static Regex ValidPhoneNumber = new Regex(@"\([0-9]{3}\) [0-9]{3}-[0-9]{4}");

        private Independent<string> _phoneNumber = new Independent<string>("");

        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set { _phoneNumber.Value = value; }
        }

        public bool PhoneNumberIsValid
        {
            get { return ValidPhoneNumber.IsMatch(_phoneNumber); }
        }
    }
}
