﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Windows;
using UpdateControls.Fields;
using UpdateControls.XAML;

namespace ValidationExample
{
    public class MyViewModel : ViewModelBase, INotifyDataErrorInfo
    {
        private MyModel _model;
        private Dependent<bool> _phoneNumberInvalid;
        private bool _phoneNumberWasInvalid;

        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        public MyViewModel(MyModel model)
        {
            _model = model;

            // Create a dependent boolean that is true when the phone number is invalid.
            _phoneNumberInvalid = new Dependent<bool>(() => !_model.PhoneNumberIsValid);

            // When the dependent goes out-of-date, bring it back up-to-date at the next opportunity.
            _phoneNumberInvalid.DependentSentry.Invalidated += delegate
            {
                Deployment.Current.Dispatcher.BeginInvoke(delegate
                {
                    // Get the new value of the dependent. This brings it up-to-date.
                    bool phoneNumberIsInvalid = _phoneNumberInvalid;

                    // Fire the event if the status has changed.
                    if (phoneNumberIsInvalid != _phoneNumberWasInvalid && ErrorsChanged != null)
                        ErrorsChanged(this, new DataErrorsChangedEventArgs("PhoneNumber"));

                    _phoneNumberWasInvalid = phoneNumberIsInvalid;
                });
            };

            // Get the initial value of the dependent. This brings it up-to-date.
            _phoneNumberWasInvalid = _phoneNumberInvalid;
        }

        public string PhoneNumber
        {
            get { return Get(() => _model.PhoneNumber); }
            set { _model.PhoneNumber = value; }
        }

        public IEnumerable GetErrors(string propertyName)
        {
            if (propertyName == "PhoneNumber")
                if (_phoneNumberInvalid)
                    yield return "Please enter (###) ###-####";
        }

        public bool HasErrors
        {
            get { return _phoneNumberInvalid; }
        }
    }
}
