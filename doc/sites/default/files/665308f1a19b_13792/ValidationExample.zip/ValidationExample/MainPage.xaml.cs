﻿using System.Windows.Controls;

namespace ValidationExample
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            // Create the model and the view model.
            MyModel model = new MyModel();
            MyViewModel viewModel = new MyViewModel(model);

            // No ForView.Wrap() this time. We're using ViewModelBase.
            DataContext = viewModel;
        }
    }
}
