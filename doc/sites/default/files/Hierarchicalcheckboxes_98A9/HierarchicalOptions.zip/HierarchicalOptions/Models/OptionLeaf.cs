using System.Collections.Generic;
using System.Linq;
using UpdateControls.Fields;

namespace HierarchicalOptions.Models
{
    public class OptionLeaf : Option
    {
        private Independent<bool> _selected = new Independent<bool>();

        public OptionLeaf(string name)
            : base(name)
        {
        }

        public bool Selected
        {
            get { return _selected; }
            set { _selected.Value = value; }
        }

        public override IEnumerable<Option> Children
        {
            get { return Enumerable.Empty<Option>(); }
        }

        public override IEnumerable<OptionLeaf> Leaves
        {
            get { return Enumerable.Repeat(this, 1); }
        }
    }
}
