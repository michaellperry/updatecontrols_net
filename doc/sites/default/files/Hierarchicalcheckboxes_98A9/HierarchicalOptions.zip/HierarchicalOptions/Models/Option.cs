﻿using System.Collections.Generic;

namespace HierarchicalOptions.Models
{
    public abstract class Option
    {
        private string _name;

        public Option(string name)
        {
            _name = name;
        }

        public string Name
        {
		    get { return _name; }
        }

        public abstract IEnumerable<Option> Children { get; }
        public abstract IEnumerable<OptionLeaf> Leaves { get; }
    }
}
