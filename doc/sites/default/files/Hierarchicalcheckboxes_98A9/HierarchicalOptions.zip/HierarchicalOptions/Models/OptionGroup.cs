using System.Collections.Generic;
using System.Linq;

namespace HierarchicalOptions.Models
{
    public class OptionGroup : Option
    {
        private List<Option> _children = new List<Option>();

        public OptionGroup(string name)
            : base(name)
        {
        }

        public OptionGroup Add(Option child)
        {
            _children.Add(child);
            return this;
        }

        public override IEnumerable<Option> Children
        {
            get { return _children; }
        }

        public override IEnumerable<OptionLeaf> Leaves
        {
            get { return _children.SelectMany(child => child.Leaves); }
        }
    }
}
