
namespace FunctionalMVVM.Models
{
	public class Order
	{
		private Product _product;
		private decimal _price;

		public Order(Product product, decimal price)
		{
			_product = product;
			_price = price;
		}

		public Product Product
		{
			get { return _product; }
		}

		public decimal Price
		{
			get { return _price; }
		}
	}
}
