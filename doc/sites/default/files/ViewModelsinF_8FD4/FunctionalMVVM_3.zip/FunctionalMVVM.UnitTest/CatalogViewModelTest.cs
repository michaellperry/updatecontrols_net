﻿using FunctionalMVVM.Models;
using FunctionalMVVM.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Collections.Generic;

namespace FunctionalMVVM.UnitTest
{
	[TestClass]
	public class CatalogViewModelTest
	{
		private Customer _customer;
		private Catalog _catalog;
		private CatalogViewModel _catalogViewModel;

		[TestInitialize]
		public void Initialize()
		{
			_customer = new Customer();
			_catalog = new Catalog();
			_catalogViewModel = new CatalogViewModel(_catalog, _customer, new CatalogNavigation());
		}

		[TestMethod]
		public void CanDisplayCustomerGreeting()
		{
			_customer.Name = "Joe Smith";

			Assert.AreEqual("Hello, Joe Smith", _catalogViewModel.CustomerGreeting);
		}

		[TestMethod]
		public void CanChangeCustomerName()
		{
			_customer.Name = "Joe Smith";

			_catalogViewModel.CustomerName = "Joseph Smith";

			Assert.AreEqual("Hello, Joseph Smith", _catalogViewModel.CustomerGreeting);
		}

		[TestMethod]
		public void CanDisplayProducts()
		{
			_customer.Name = "Joe Smith";
			_catalog.NewProduct().Name = "Shoes";

			Assert.AreEqual(1, _catalogViewModel.Products.Count());
			Assert.AreEqual("Shoes", _catalogViewModel.Products.First().Name);
		}

		[TestMethod]
		public void RegularCustomersPayFullPrice()
		{
			_catalog.NewProduct().BasePrice = 25.34m;

			Assert.AreEqual(1, _catalogViewModel.Products.Count());
			Assert.AreEqual(25.34m, _catalogViewModel.Products.First().Price);
		}

		[TestMethod]
		public void PreferredCustomersPayDiscountedPrice()
		{
			_customer.IsPreferred = true;
			_catalog.NewProduct().BasePrice = 25.34m;

			Assert.AreEqual(1, _catalogViewModel.Products.Count());
			Assert.AreEqual(22.81m, _catalogViewModel.Products.First().Price);
		}

		[TestMethod]
		public void CustomerHasNoOrders()
		{
			Assert.IsFalse(_catalogViewModel.Orders.Any());
		}

		[TestMethod]
		public void WhenNoProductSelected_ThenCustomerCannotPlaceOrder()
		{
			Assert.IsFalse(_catalogViewModel.PlaceOrder.CanExecute(null));
		}

		[TestMethod]
		public void WhenProductIsSelected_ThenCustomerCanPlaceOrder()
		{
			_catalog.NewProduct().Name = "Shoes";
			_catalogViewModel.SelectedProduct = _catalogViewModel.Products.First();

			Assert.IsTrue(_catalogViewModel.PlaceOrder.CanExecute(null));
		}

		[TestMethod]
		public void WhenOrderIsPlaced_ThenOrderedProductAppears()
		{
			Product product = _catalog.NewProduct();
			product.Name = "Shoes";
			product.BasePrice = 35.21m;
			_catalogViewModel.SelectedProduct = _catalogViewModel.Products.First();
			_catalogViewModel.PlaceOrder.Execute(null);

			Assert.IsTrue(_catalogViewModel.Orders.Single().ProductName == "Shoes");
			Assert.IsTrue(_catalogViewModel.Orders.Single().Price == 35.21m);
		}
	}
}
