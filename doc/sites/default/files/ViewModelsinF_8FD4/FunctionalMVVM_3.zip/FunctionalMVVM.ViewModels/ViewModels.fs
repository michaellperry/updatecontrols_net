﻿
namespace FunctionalMVVM.ViewModels

open FunctionalMVVM.Models
open UpdateControls.XAML

type ProductViewModel(product: Product, customer: Customer) =
    member this.Product = product
    member this.Name = product.Name
    member this.Price =
        System.Decimal.Round((product.BasePrice * if customer.IsPreferred then 0.9m else 1.0m), 2)
    override this.Equals(obj) =
        match obj with
            | null -> false
            | :? ProductViewModel as that -> that.Product = product
            | _ -> false
    override this.GetHashCode() = product.GetHashCode()

type OrderViewModel(order: Order) =
    member this.Order = order
    member this.ProductName = order.Product.Name
    member this.Price = order.Price
    override this.Equals(obj) =
        match obj with
            | null -> false
            | :? OrderViewModel as that -> that.Order = order
            | _ -> false
    override this.GetHashCode() = order.GetHashCode()

type CatalogViewModel(catalog: Catalog, customer: Customer, navigation: CatalogNavigation) =
    member this.CustomerName
        with get() = customer.Name
        and set(value) = customer.Name <- value
    member this.IsPreferred
        with get() = customer.IsPreferred
        and set(value) = customer.IsPreferred <- value
    member this.CustomerGreeting = "Hello, " + customer.Name
    member this.Products = Seq.map (fun product -> ProductViewModel(product, customer)) catalog.Products
    member this.SelectedProduct
        with get() =
            if navigation.SelectedProduct = null then
                Unchecked.defaultof<ProductViewModel>
            else
                ProductViewModel(navigation.SelectedProduct, customer)
        and set(value : ProductViewModel) =
            navigation.SelectedProduct <-
                if value = Unchecked.defaultof<ProductViewModel> then null else value.Product
    member this.Orders =
        Seq.map (fun order -> OrderViewModel(order)) customer.Orders
    member this.PlaceOrder =
        MakeCommand
            .When(fun () -> navigation.SelectedProduct <> null)
            .Do(fun () -> customer.PlaceOrder(navigation.SelectedProduct))