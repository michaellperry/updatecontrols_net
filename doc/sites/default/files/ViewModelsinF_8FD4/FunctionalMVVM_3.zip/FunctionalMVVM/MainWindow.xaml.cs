﻿using System.Windows;
using FunctionalMVVM.Models;
using FunctionalMVVM.ViewModels;
using UpdateControls.XAML;

namespace FunctionalMVVM
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			Customer realCustomer = new Customer();
			Catalog catalog = new Catalog();
			CatalogNavigation navigation = new CatalogNavigation();
			DataContext = ForView.Wrap(new CatalogViewModel(catalog, realCustomer, navigation));
			realCustomer.Name = "Michael Perry";
			AddProduct(catalog, "Shoes", 24.39m);
			AddProduct(catalog, "Socks", 9.30m);
		}

		private static Product AddProduct(Catalog catalog, string name, decimal basePrice)
		{
			Product product = catalog.NewProduct();
			product.Name = name;
			product.BasePrice = basePrice;
			return product;
		}
	}
}
