﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ProjectPlan
{
    [TestClass]
    public class StartDateTest
    {
        private Project _project;
        private Task _firstTask;

        [TestInitialize]
        public void Initialize()
        {
            _project = new Project();
            _project.StartDate = new DateTime(2011, 3, 5);
            _firstTask = new Task(_project);
            _firstTask.Duration = TimeSpan.FromDays(1);
        }

        [TestMethod]
        public void ProjectDeterminesStartDateWhenNoPrerequisites()
        {
            Assert.AreEqual(new DateTime(2011, 3, 5), _firstTask.StartDate);
        }

        [TestMethod]
        public void PrerequisiteDeterminesStartDateWhenPresent()
        {
            Task secondTask = new Task(_project);
            secondTask.AddPrerequisite(_firstTask);

            Assert.AreEqual(new DateTime(2011, 3, 6), secondTask.StartDate);
        }
    }
}
