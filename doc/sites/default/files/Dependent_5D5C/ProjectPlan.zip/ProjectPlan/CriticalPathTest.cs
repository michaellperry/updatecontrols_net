﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ProjectPlan
{
    [TestClass]
    public class CriticalPathTest
    {
        private Project _project;
        private Task _firstTask;

        [TestInitialize]
        public void Initialize()
        {
            _project = new Project();
            _project.StartDate = new DateTime(2011, 3, 5);
            _firstTask = new Task(_project);
            _firstTask.Duration = TimeSpan.FromDays(1);
        }

        [TestMethod]
        public void TaskWithNoPrerequisiteIsBasedOnProjectStartDate()
        {
            Assert.AreEqual(new DateTime(2011, 3, 6), _firstTask.EndDate);
        }

        [TestMethod]
        public void TaskWithPrerequisiteIsBasedOnPrerequisiteStartDate()
        {
            Task secondTask = new Task(_project);
            secondTask.Duration = TimeSpan.FromDays(2);
            secondTask.AddPrerequisite(_firstTask);

            Assert.AreEqual(new DateTime(2011, 3, 8), secondTask.EndDate);
        }

        [TestMethod]
        public void CycleIsPrevented()
        {
            Task secondTask = new Task(_project);
            secondTask.AddPrerequisite(_firstTask);
            _firstTask.AddPrerequisite(secondTask);

            DateTime endDate = secondTask.EndDate;
            // Stack overflow exception was not thrown.
        }
    }
}
