﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ProjectPlan
{
    [TestClass]
    public class EndDateTest
    {
        private Project _project;
        private Task _task;

        [TestInitialize]
        public void Initialize()
        {
            _project = new Project();
            _project.StartDate = new DateTime(2011, 3, 5);
            _task = new Task(_project);
            _task.Duration = TimeSpan.FromDays(1);
        }

        [TestMethod]
        public void CanCalculateEndDate()
        {
            Assert.AreEqual(new DateTime(2011, 3, 6), _task.EndDate);
        }

        [TestMethod]
        public void CalculatesOnceWhenAccessedOnce()
        {
            DateTime endDate = _task.EndDate;

            Assert.AreEqual(1, _task.CalculationCount);
        }

        [TestMethod]
        public void CalculatesOnceWhenNotChanged()
        {
            DateTime endDate1 = _task.EndDate;
            DateTime endDate2 = _task.EndDate;

            Assert.AreEqual(1, _task.CalculationCount);
        }

        [TestMethod]
        public void CalculateAgainWhenStartDateChanges()
        {
            DateTime endDate1 = _task.EndDate;
            _project.StartDate = new DateTime(2011, 3, 6);
            DateTime endDate2 = _task.EndDate;

            Assert.AreEqual(new DateTime(2011, 3, 7), endDate2);
            Assert.AreEqual(2, _task.CalculationCount);
        }

        [TestMethod]
        public void CalculateAgainWhenDurationChanges()
        {
            DateTime endDate1 = _task.EndDate;
            _task.Duration = TimeSpan.FromDays(2);
            DateTime endDate2 = _task.EndDate;

            Assert.AreEqual(new DateTime(2011, 3, 7), endDate2);
            Assert.AreEqual(2, _task.CalculationCount);
        }
    }
}
