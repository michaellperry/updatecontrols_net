﻿using System.Windows;
using SurveyEditor.DataModel;
using SurveyEditor.NavigationModel;
using SurveyEditor.ViewModel;
using UpdateControls.XAML;

namespace SurveyEditor
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();

			Game game = new Game();
			game.NewSurvey()
				.SetQuestion("Name a kind of dog")
				.AddAnswer("Poodle")
				.AddAnswer("Pug")
				.AddAnswer("Golden Retriever");
			game.NewSurvey()
				.SetQuestion("Name something you do with your feet")
				.AddAnswer("Walk")
				.AddAnswer("Run")
				.AddAnswer("Dance")
				.AddAnswer("Vote");

			GameViewModel vm = new GameViewModel(game, new GameNavigationModel());
			this.DataContext = ForView.Wrap(vm);
			//this.DataContext = vm;
		}
	}
}
