using SurveyEditor.DataModel;

namespace SurveyEditor
{
	public static class Extensions
	{
		public static Survey SetQuestion(this Survey survey, string question)
		{
			survey.Question = question;
			return survey;
		}

		public static Survey AddAnswer(this Survey survey, string response)
		{
			survey.NewAnswer().Response = response;
			return survey;
		}
	}
}
