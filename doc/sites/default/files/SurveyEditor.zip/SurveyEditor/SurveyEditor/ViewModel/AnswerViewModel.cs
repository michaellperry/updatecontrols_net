using SurveyEditor.DataModel;
using SurveyEditor.NavigationModel;
using UpdateControls;

namespace SurveyEditor.ViewModel
{
	public class AnswerViewModel
	{
		private Answer _answer;
		private Survey _survey;
		private GameNavigationModel _navigation;

		private AnswerViewModel(Answer answer, Survey survey, GameNavigationModel navigation)
		{
			_answer = answer;
			_survey = survey;
			_navigation = navigation;
		}

		public string Response
		{
			get { return _answer.Response ?? "<New Answer>"; }
			set { _answer.Response = value; }
		}

		public bool IsSelected
		{
			get { return _navigation.SelectedAnswer != null && _navigation.SelectedAnswer.Answer == _answer; }
			set { _navigation.SelectedAnswer = value ? new SurveyAnswer(_survey, _answer) : null; }
		}

		public override bool Equals(object obj)
		{
			if (obj == this)
				return true;
			AnswerViewModel that = obj as AnswerViewModel;
			if (that == null)
				return false;
			return object.Equals(this._answer, that._answer);
		}

		public override int GetHashCode()
		{
			return _answer.GetHashCode();
		}

		public static AnswerViewModel Wrap(Answer answer, Survey survey, GameNavigationModel navigation)
		{
			if (answer == null)
				return null;
			else
				return new AnswerViewModel(answer, survey, navigation);
		}

		public static Answer Unwrap(AnswerViewModel viewModel)
		{
			if (viewModel == null)
				return null;
			else
				return viewModel._answer;
		}
	}
}
