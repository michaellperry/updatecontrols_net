﻿using System.Collections.Generic;
using System.Linq;
using SurveyEditor.DataModel;
using SurveyEditor.NavigationModel;
using System.Windows.Input;
using UpdateControls.XAML;

namespace SurveyEditor.ViewModel
{
    public class GameViewModel
	{
		private Game _game;
		private GameNavigationModel _navigation;

		public GameViewModel(Game game, GameNavigationModel navigation)
		{
			_game = game;
			_navigation = navigation;
		}

		public IEnumerable<SurveyViewModel> Surveys
		{
			get { return _game.Surveys.Select(s => SurveyViewModel.Wrap(s, _navigation)); }
		}

		public ICommand NewSurvey
		{
			get
			{
				return MakeCommand
					.Do(() => _navigation.SelectedSurvey = _game.NewSurvey());
			}
		}

		public ICommand NewAnswer
		{
			get
			{
				return MakeCommand
					.When(() => _navigation.SelectedSurvey != null || _navigation.SelectedAnswer != null)
					.Do(() =>
					{
						Survey survey =
							_navigation.SelectedSurvey != null ? _navigation.SelectedSurvey :
							_navigation.SelectedAnswer.Survey;
						Answer answer = survey.NewAnswer();
						_navigation.SelectedAnswer = new SurveyAnswer(survey, answer);
					});
			}
		}

		public ICommand Delete
		{
			get
			{
				return MakeCommand
					.When(() => _navigation.SelectedSurvey != null || _navigation.SelectedAnswer != null)
					.Do(() =>
					{
						if (_navigation.SelectedSurvey != null)
							_game.DeleteSurvey(_navigation.SelectedSurvey);
						else if (_navigation.SelectedAnswer != null)
						{
							SurveyAnswer surveyAnswer = _navigation.SelectedAnswer;
							surveyAnswer.Survey.DeleteAnswer(surveyAnswer.Answer);
							_navigation.SelectedSurvey = surveyAnswer.Survey;
						}
					});
			}
		}
	}
}
