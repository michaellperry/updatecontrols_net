using SurveyEditor.DataModel;

namespace SurveyEditor.NavigationModel
{
	public class SurveyAnswer
	{
		private Survey _survey;
		private Answer _answer;

		public SurveyAnswer(Survey survey, Answer answer)
		{
			_survey = survey;
			_answer = answer;
		}

		public Survey Survey
		{
			get { return _survey; }
		}

		public Answer Answer
		{
			get { return _answer; }
		}
	}
}
