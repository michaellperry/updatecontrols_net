
namespace BindingVisualStates
{
	public enum CompassDirection
	{
		North,
		East,
		South,
		West
	}
}
