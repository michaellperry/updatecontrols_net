
namespace BindingVisualStatesSL4
{
	public enum CompassDirection
	{
		North,
		East,
		South,
		West
	}
}
