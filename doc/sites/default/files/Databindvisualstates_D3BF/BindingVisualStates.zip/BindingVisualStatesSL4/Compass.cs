﻿using System.ComponentModel;

namespace BindingVisualStatesSL4
{
    public class Compass : INotifyPropertyChanged
	{
		private CompassDirection _direction = CompassDirection.East;

		public CompassDirection Direction
		{
			get { return _direction; }
			set
			{
				if (_direction != value)
				{
					_direction = value;
					FirePropertyChanged("Direction");
				}
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		private void FirePropertyChanged(string propertyName)
		{
			if (PropertyChanged != null)
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
