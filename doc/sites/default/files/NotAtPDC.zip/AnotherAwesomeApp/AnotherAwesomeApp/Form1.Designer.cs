﻿namespace AnotherAwesomeApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.firstNameTextBox = new UpdateControls.Forms.UpdateTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lastNameTextBox = new UpdateControls.Forms.UpdateTextBox();
            this.fullNameLabel = new UpdateControls.Forms.UpdateLabel();
            this.titleComponent = new UpdateControls.Forms.UpdateComponent(this.components);
            this.SuspendLayout();
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(172, 12);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 0;
            this.firstNameTextBox.GetText += new UpdateControls.Forms.GetStringDelegate(this.firstNameTextBox_GetText);
            this.firstNameTextBox.SetText += new UpdateControls.Forms.SetStringDelegate(this.firstNameTextBox_SetText);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name:";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(172, 39);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 3;
            this.lastNameTextBox.GetText += new UpdateControls.Forms.GetStringDelegate(this.lastNameTextBox_GetText);
            this.lastNameTextBox.SetText += new UpdateControls.Forms.SetStringDelegate(this.lastNameTextBox_SetText);
            // 
            // fullNameLabel
            // 
            this.fullNameLabel.AutoSize = true;
            this.fullNameLabel.Location = new System.Drawing.Point(188, 73);
            this.fullNameLabel.Name = "fullNameLabel";
            this.fullNameLabel.Size = new System.Drawing.Size(66, 13);
            this.fullNameLabel.TabIndex = 4;
            this.fullNameLabel.Text = "updateLabel";
            this.fullNameLabel.GetText += new UpdateControls.Forms.GetStringDelegate(this.fullNameLabel_GetText);
            // 
            // titleComponent
            // 
            this.titleComponent.Update += new UpdateControls.Forms.ActionDelegate(this.titleComponent_Update);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.fullNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.firstNameTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UpdateControls.Forms.UpdateTextBox firstNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private UpdateControls.Forms.UpdateTextBox lastNameTextBox;
        private UpdateControls.Forms.UpdateLabel fullNameLabel;
        private UpdateControls.Forms.UpdateComponent titleComponent;
    }
}

