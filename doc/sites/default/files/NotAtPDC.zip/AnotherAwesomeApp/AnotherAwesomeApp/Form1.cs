﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AnotherAwesomeApp
{
    public partial class Form1 : Form
    {
        private Person _person;

        public Form1()
        {
         _person = new Person();
           InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private string firstNameTextBox_GetText()
        {
            return _person.FirstName;
        }

        private void firstNameTextBox_SetText(string value)
        {
            _person.FirstName = value;
        }

        private string lastNameTextBox_GetText()
        {
            return _person.LastName;
        }

        private void lastNameTextBox_SetText(string value)
        {
            _person.LastName = value;
        }

        private string fullNameLabel_GetText()
        {
            return string.Format("{0}, {1}", _person.LastName, _person.FirstName);
        }

        private void titleComponent_Update()
        {
            this.Text = string.Format("Person - {0}, {1}", _person.LastName, _person.FirstName);
        }
    }
}
