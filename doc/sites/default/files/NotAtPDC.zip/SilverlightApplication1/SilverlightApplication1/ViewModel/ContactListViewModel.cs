﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Awesome.DataModel;
using Awesome.Extensions;
using Awesome.NavigationModel;
using UpdateControls.XAML;

namespace Awesome.ViewModel
{
    public class ContactListViewModel
    {
        private ContactList _contactList;
        private ContactListNavigationModel _navigation;

        public ContactListViewModel(ContactList contactList, ContactListNavigationModel navigation)
        {
            _contactList = contactList;
            _navigation = navigation;
        }

        public string Filter
        {
            get { return _navigation.Filter; }
            set { _navigation.Filter = value; }
        }

        public IEnumerable<PersonViewModel> People
        {
            get
            {
                return
                    from p in _contactList.People
                    where p.First.ContainsIgnoreCase(_navigation.Filter) || p.Last.ContainsIgnoreCase(_navigation.Filter)
                    select new PersonViewModel(p);
            }
        }

        public PersonViewModel SelectedPerson
        {
            get
            {
                return _navigation.SelectedPerson != null
                    ? new PersonViewModel(_navigation.SelectedPerson)
                    : null;
            }
            set
            {
            	_navigation.SelectedPerson = value != null
                    ? value.Person
                    : null;
            }
        }

        public void NextPerson()
        {
            List<Person> people = _contactList.People.ToList();
            int index = people.IndexOf(_navigation.SelectedPerson);
            _navigation.SelectedPerson = people[(index + 1) % people.Count];
        }

        public string Title
        {
            get
            {
                return _navigation.SelectedPerson == null ? string.Empty : _navigation.SelectedPerson.Last;
            }
        }

        //public ICommand NewPerson
        //{
        //    get
        //    {
        //        return MakeCommand
        //            .Do(()=> ShowPersonWindow(_contactList.NewPerson()));
        //    }
        //}

        //public ICommand EditPerson
        //{
        //    get
        //    {
        //        return MakeCommand
        //            .When(() => _navigation.SelectedPerson != null)
        //            .Do(() => ShowPersonWindow(_navigation.SelectedPerson));
        //    }
        //}

        //public ICommand DeletePerson
        //{
        //    get
        //    {
        //        return MakeCommand
        //            .When(() => _navigation.SelectedPerson != null)
        //            .Do(() => _contactList.DeletePerson(_navigation.SelectedPerson));
        //    }
        //}


        //private void ShowPersonWindow(Person person)
        //{
        //    PersonWindow window = new PersonWindow();
        //    window.DataContext = new PersonViewModel(person);
        //    window.Show();
        //}
    }
}
