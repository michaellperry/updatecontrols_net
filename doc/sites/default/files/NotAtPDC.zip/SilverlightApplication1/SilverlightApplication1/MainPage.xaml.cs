﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using UpdateControls;
using Awesome.ViewModel;
using Awesome.DataModel;
using Awesome.NavigationModel;

namespace SilverlightApplication1
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            ContactList contactList = new ContactList();
            Person turing = contactList.NewPerson();
            turing.First = "Alan";
            turing.Last = "Turing";
            Person vonNeumann = contactList.NewPerson();
            vonNeumann.First = "John";
            vonNeumann.Last = "von Neumann";
            Person lovelace = contactList.NewPerson();
            lovelace.First = "Ada";
            lovelace.Last = "Lovelace";
            DataContext = ForView.Wrap(new ContactListViewModel(contactList, new ContactListNavigationModel()));
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ForView.Unwrap<ContactListViewModel>(DataContext).NextPerson();
        }
    }
}
