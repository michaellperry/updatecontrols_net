﻿using System.ComponentModel;
using Awesome.DataModel;

namespace Awesome.ViewModel
{
    public class PersonViewModel
    {
        private Person _person;

        public PersonViewModel(Person person)
        {
            _person = person;
        }

        public Person Person
        {
            get { return _person; }
        }

        public string FirstName
        {
            get
            {
                return _person.First;
            }
            set
            {
                _person.First = value;
            }
        }

        public string LastName
        {
            get
            {
                return _person.Last;
            }
            set
            {
                _person.Last = value;
            }
        }

        public string FullName
        {
            get
            {
                return string.Format("{0}, {1}", _person.Last, _person.First);
            }
        }

        public string Title
        {
            get
            {
                return string.Format("Person - {0}", FullName);
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        private void FirePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region Equals and GetHashCode

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            PersonViewModel that = obj as PersonViewModel;
            if (that == null)
                return false;
            return _person.Equals(that._person);
        }

        public override int GetHashCode()
        {
            return _person.GetHashCode();
        }

        #endregion
    }
}
