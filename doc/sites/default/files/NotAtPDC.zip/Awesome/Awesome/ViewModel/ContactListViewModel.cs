﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Awesome.DataModel;
using Awesome.Extensions;
using Awesome.NavigationModel;
using Awesome.View;
using UpdateControls.XAML;

namespace Awesome.ViewModel
{
    public class ContactListViewModel
    {
        private ContactList _contactList;
        private ContactListNavigationModel _navigation;

        public ContactListViewModel(ContactList contactList, ContactListNavigationModel navigation)
        {
            _contactList = contactList;
            _navigation = navigation;
        }

        public string Filter
        {
            get { return _navigation.Filter; }
            set { _navigation.Filter = value; }
        }

        public IEnumerable<PersonViewModel> People
        {
            get
            {
                return
                    from p in _contactList.People
                    where p.First.ContainsIgnoreCase(_navigation.Filter) || p.Last.ContainsIgnoreCase(_navigation.Filter)
                    select new PersonViewModel(p);
            }
        }

        public PersonViewModel SelectedPerson
        {
            get
            {
                return _navigation.SelectedPerson != null
                    ? new PersonViewModel(_navigation.SelectedPerson)
                    : null;
            }
            set
            {
            	_navigation.SelectedPerson = value != null
                    ? value.Person
                    : null;
            }
        }

        public ICommand NewPerson
        {
            get
            {
                return MakeCommand
                    .Do(()=> ShowPersonWindow(_contactList.NewPerson()));
            }
        }

        public ICommand EditPerson
        {
            get
            {
                return MakeCommand
                    .When(() => _navigation.SelectedPerson != null)
                    .Do(() => ShowPersonWindow(_navigation.SelectedPerson));
            }
        }

        public ICommand DeletePerson
        {
            get
            {
                return MakeCommand
                    .When(() => _navigation.SelectedPerson != null)
                    .Do(() => _contactList.DeletePerson(_navigation.SelectedPerson));
            }
        }


        private void ShowPersonWindow(Person person)
        {
            PersonWindow window = new PersonWindow();
            // NOTE: I forgot to wrap this view model before setting the data context.
            // That's why the full name is not updating in the video.
            // Add ForView.Wrap() and it will work.
            window.DataContext = new PersonViewModel(person);
            window.Show();
        }
    }
}
