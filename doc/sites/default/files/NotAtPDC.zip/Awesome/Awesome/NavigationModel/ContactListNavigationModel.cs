﻿using Awesome.DataModel;
using UpdateControls;

namespace Awesome.NavigationModel
{
    public class ContactListNavigationModel
    {
        private Person _selectedPerson;
        private string _filter;

        private Independent _indSelectedPerson = new Independent();
        private Independent _indFilter = new Independent();

        public Person SelectedPerson
        {
            get { _indSelectedPerson.OnGet(); return _selectedPerson; }
            set { _indSelectedPerson.OnSet(); _selectedPerson = value; }
        }

        public string Filter
        {
            get { _indFilter.OnGet(); return _filter; }
            set { _indFilter.OnSet(); _filter = value; }
        }
    }
}
