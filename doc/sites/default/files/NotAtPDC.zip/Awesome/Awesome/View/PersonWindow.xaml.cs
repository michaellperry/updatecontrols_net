﻿using System.Windows;
using Awesome.ViewModel;
using UpdateControls.XAML;

namespace Awesome.View
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class PersonWindow : Window
    {
        public PersonWindow()
        {
            InitializeComponent();
        }

        private void NewWindowButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a new window with a new view model.
            PersonViewModel viewModel = ForView.Unwrap<PersonViewModel>(DataContext);
            if (viewModel != null)
            {
                PersonWindow newWindow = new PersonWindow();
                newWindow.DataContext = new PersonViewModel(viewModel.Person);
                newWindow.Show();
            }
        }
    }
}
