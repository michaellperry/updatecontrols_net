﻿using System.Collections.Generic;
using UpdateControls;

namespace Awesome.DataModel
{
    public class ContactList
    {
        private List<Person> _people = new List<Person>();

        private Independent _indPeople = new Independent();

        public IEnumerable<Person> People
        {
            get { _indPeople.OnGet(); return _people; }
        }

        public Person NewPerson()
        {
            _indPeople.OnSet();
            Person person = new Person();
            _people.Add(person);
            return person;
        }

        public void DeletePerson(Person victim)
        {
            _indPeople.OnSet();
            _people.Remove(victim);
        }
    }
}
