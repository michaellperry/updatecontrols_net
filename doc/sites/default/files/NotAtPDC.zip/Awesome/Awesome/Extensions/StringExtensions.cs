﻿using System;

namespace Awesome.Extensions
{
    public static class StringExtensions
    {
        public static bool ContainsIgnoreCase(this string wholeString, string subString)
        {
            if (String.IsNullOrEmpty(subString))
                return true;
            if (String.IsNullOrEmpty(wholeString))
                return false;
            return wholeString.IndexOf(subString, StringComparison.CurrentCultureIgnoreCase) != -1;
        }
    }
}
