﻿using System.Windows;
using Awesome.DataModel;
using Awesome.NavigationModel;
using Awesome.View;
using Awesome.ViewModel;
using UpdateControls.XAML;

namespace Awesome
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            //MainWindow = new PersonWindow();
            //MainWindow.DataContext = ForView.Wrap(new PersonViewModel(new Person()));
            //MainWindow.Show();

            MainWindow = new ContactListWindow();
            ContactList contactList = new ContactList();
            Person turing = contactList.NewPerson();
            turing.First = "Alan";
            turing.Last = "Turing";
            Person vonNeumann = contactList.NewPerson();
            vonNeumann.First = "John";
            vonNeumann.Last = "von Neumann";
            Person lovelace = contactList.NewPerson();
            lovelace.First = "Ada";
            lovelace.Last = "Lovelace";
            MainWindow.DataContext = ForView.Wrap(new ContactListViewModel(contactList, new ContactListNavigationModel()));
            MainWindow.Show();
        }
    }
}
