﻿using System;
using MVC1.Model;
using MVC1.View;
using UpdateControls.XAML;

namespace MVC1.Controller
{
    public class CalculatorController : ICalculatorController
    {
        private CalculatorView view;
        private ICalculatorModel model;

        public CalculatorController(CalculatorView view, ICalculatorModel model)
        {
            this.view = view;
            this.model = model;

			/*
            view.SetModel(model);
            view.SetController(this);
			*/
        }

		/*
        public void SetSalary(double salary)
        {
            model.Salary = salary;
        }

        public void SetTaxes(double taxes)
        {
            model.Taxes = taxes;
        }
		*/

		public void Bind()
		{
			view.DataContext = ForView.Wrap(model);
		}
    }
}
