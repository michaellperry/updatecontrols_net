namespace MVC1.Controller
{
    public interface ICalculatorController
    {
		/*
        void SetSalary(double salary);
        void SetTaxes(double taxes);
		*/
		void Bind();
    }
}