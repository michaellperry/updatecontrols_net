﻿using System.Windows.Controls;
using MVC1.Controller;
using MVC1.Model;

namespace MVC1
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            ICalculatorModel model = new CalculatorModel();
            ICalculatorController controller = new CalculatorController(view, model);
			controller.Bind();
        }
    }
}
