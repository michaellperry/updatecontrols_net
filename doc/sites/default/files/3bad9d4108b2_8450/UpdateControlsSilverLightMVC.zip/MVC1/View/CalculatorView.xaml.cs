﻿using System;
using System.Windows.Controls;
using MVC1.Controller;
using MVC1.Model;

namespace MVC1.View
{
    public partial class CalculatorView : Page
    {
		/*
        private ICalculatorModel model;
        private ICalculatorController controller;
		 * */

        public CalculatorView()
        {
            InitializeComponent();
        }

		private void SalaryTextBoxChanged(object sender, TextChangedEventArgs e)
		{
			((TextBox)sender).GetBindingExpression(TextBox.TextProperty).UpdateSource();
		}

		/*
        public void SetModel(ICalculatorModel calculatorModel)
        {
            model = calculatorModel;
            SalaryTextBox.TextChanged += SalaryTextBoxChanged;
            model.TaxesChanged += ModelTaxesChanged;
        }

        private void ModelTaxesChanged(object sender, CalculatorEventArgs e)
        {
            TaxesTextBox.Text = e.Taxes.ToString();
        }

        private void SalaryTextBoxChanged(object sender, TextChangedEventArgs e)
        {
            controller.SetSalary(Double.Parse(SalaryTextBox.Text));
        }

        public void SetController(ICalculatorController calculatorController)
        {
            controller = calculatorController;
        }
		*/
    }
}
