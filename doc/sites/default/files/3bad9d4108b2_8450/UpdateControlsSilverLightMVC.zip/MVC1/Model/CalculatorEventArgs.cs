﻿using System;

namespace MVC1.Model
{
    public class CalculatorEventArgs : EventArgs
    {
        public CalculatorEventArgs(ICalculatorModel model)
        {
            this.Salary = model.Salary;
            this.Taxes = model.Taxes;
        }

        public double Salary { get; set; }
        public double Taxes { get; set; }
    }
}
