﻿using System;
using UpdateControls;

namespace MVC1.Model
{
    public class CalculatorModel : ICalculatorModel
    {
        private double salary;
		private Independent _indSalary = new Independent();
        /*private double taxes;*/
        public readonly double TAX_RATE = 0.3d;

        public double Salary
        {
			get { _indSalary.OnGet(); return salary; }
            set
            {
                if (value == this.salary) return;
				_indSalary.OnSet();
                salary = value;
                /*Taxes = salary*TAX_RATE;*/
            }
        }

        public double Taxes
        {
            get { return /*taxes*/ Salary*TAX_RATE; }
            /*
			set
            {
                if (value == this.taxes) return;
                taxes = value;
                OnTaxesChanged(new CalculatorEventArgs(this));
            }
			*/
        }

		/*
        public event EventHandler<CalculatorEventArgs> TaxesChanged;

        protected void OnTaxesChanged(CalculatorEventArgs e)
        {
            if (TaxesChanged != null)
                TaxesChanged(this, e); // fire event
        }
		*/
    }
}
