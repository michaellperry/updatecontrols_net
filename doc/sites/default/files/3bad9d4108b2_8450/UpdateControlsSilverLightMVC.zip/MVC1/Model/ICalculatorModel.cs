﻿using System;

namespace MVC1.Model
{
    public interface ICalculatorModel
    {
        double Salary { get; set; }
        double Taxes { get; /*set;*/ }

        /*event EventHandler<CalculatorEventArgs> TaxesChanged;*/
    }
}
