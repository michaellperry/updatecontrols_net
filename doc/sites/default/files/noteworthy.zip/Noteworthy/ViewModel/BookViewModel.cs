﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Noteworthy.DataModel;

namespace Noteworthy.ViewModel
{
    public class BookViewModel
    {
        private Book _book;

        public BookViewModel(Book book)
        {
            _book = book;
        }

        public IEnumerable<ArticleViewModel> Articles
        {
            get { return _book.Articles.Select(a => new ArticleViewModel(a)); }
        }

    }
}
