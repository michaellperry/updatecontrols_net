using Noteworthy.DataModel;
using Noteworthy.NavigationModel;
using System;

namespace Noteworthy.ViewModel
{
    /// <summary>
    /// Interprets a tag from the point-of-view of user navigation.
    /// </summary>
    public class TagViewModel
    {
        private Blog _blog;
        private Tag _tag;
        private BlogNavigationModel _navigation;

        public TagViewModel(Blog blog, Tag tag, BlogNavigationModel navigation)
        {
            _blog = blog;
            _tag = tag;
            _navigation = navigation;
        }

        /// <summary>
        /// The name of the tag.
        /// </summary>
        public string Name
        {
            get
            {
                if (_tag == null)
                    return string.Empty;
                else
                    return _tag.TagName;
            }
            set
            {
                if (_tag != null)
                {
                    _tag.TagName = value;

                    // When the user changes the name, save their changes.
                    _blog.SubmitChanges();
                }
            }
        }

        /// <summary>
        /// True if this tag is selected. Multiple selection is supported
        /// by the navigation model.
        /// </summary>
        public bool TagIsSelected
        {
            get { return _navigation.TagIsSelected(_tag); }
            set
            {
                if (value)
                    _navigation.AddSelectedTag(_tag);
                else
                    _navigation.RemoveSelectedTag(_tag);
            }
        }

        ///////////////////////////////////////////////////////////
        // A view model that is attached to items in a list must
        // implement Equals and GetHashCode. This allows the view
        // to recognize the selected item in the list. Equals and
        // GetHashCode are based on the data model object that the
        // view model represents, not any other context object or
        // navigation object.
        ///////////////////////////////////////////////////////////

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            TagViewModel that = obj as TagViewModel;
            if (that == null)
                return false;
            return Object.Equals(this._tag, that._tag);
        }

        public override int GetHashCode()
        {
            return _tag == null ? 0 : _tag.GetHashCode();
        }

        ///////////////////////////////////////////////////////////
        // Create static methods to wrap and unwrap a data model
        // object in a view model. This allows the data model
        // object to be null when appropriate.
        ///////////////////////////////////////////////////////////

        public static TagViewModel Wrap(Blog blog, Tag tag, BlogNavigationModel navigation)
        {
            return new TagViewModel(blog, tag, navigation);
        }

        public static Tag Unwrap(TagViewModel viewModel)
        {
            if (viewModel == null)
                return null;
            else
                return viewModel._tag;
        }
    }
}
