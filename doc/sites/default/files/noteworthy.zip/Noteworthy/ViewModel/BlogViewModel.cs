﻿using Noteworthy.DataModel;
using Noteworthy.NavigationModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using UpdateControls.XAML;

namespace Noteworthy.ViewModel
{
    /// <summary>
    /// Interprets the blog data model for the view from the point-
    /// of-view of the user's navigation.
    /// </summary>
    public class BlogViewModel
    {
        private Blog _blog;
        private BlogNavigationModel _navigation;

        public BlogViewModel(Blog blog, BlogNavigationModel navigation)
        {
            _blog = blog;
            _navigation = navigation;
        }

        /// <summary>
        /// The title of the window.
        /// </summary>
        public string Title
        {
            get
            {
                if (_navigation.SelectedArticle == null)
                    return "Noteworthy";
                else
                    return "Noteworthy - " + _navigation.SelectedArticle.Title;
            }
        }

        /// <summary>
        /// The list of tags to be used as filters.
        /// </summary>
        public IEnumerable<TagViewModel> Filters
        {
            get
            {
                // Wrap each tag in a tag view model. Let the first filter be null.
                return new List<TagViewModel>() { TagViewModel.Wrap(_blog, null, _navigation) }
                    .Union(_blog.Tags
                        .Select(t => TagViewModel.Wrap(_blog, t, _navigation)));
            }
        }

        /// <summary>
        /// The selected filter.
        /// </summary>
        public TagViewModel Filter
        {
            get { return TagViewModel.Wrap(_blog, _navigation.Filter, _navigation); }
            set { _navigation.Filter = TagViewModel.Unwrap(value); }
        }

        /// <summary>
        /// The list of articles.
        /// </summary>
        public IEnumerable<ArticleViewModel> Articles
        {
            get
            {
                // Wrap each article in an article view model.
                return _blog.ArticlesByTag(_navigation.Filter)
                    .Select(a => ArticleViewModel.Wrap(_blog, a, _navigation));
            }
        }

        /// <summary>
        /// The command to create a new article. If a filter is selected,
        /// then pre-tag the article with that filter. This ensures that
        /// it shows up in the list. Otherwise, the article will be editable,
        /// but nothing in the list would be selected.
        /// </summary>
		public ICommand NewArticle
		{
            get
            {
                return MakeCommand
                    .Do(() =>
                    {
                        // Create a new article. If a filter is selected, tag the article.
                        Article newArticle = _blog.NewArticle();
                        if (_navigation.Filter != null)
                            newArticle.AddTag(_navigation.Filter);

                        // Select the article.
                        _navigation.SelectedArticle = newArticle;

                        // Write to the database.
                        _blog.SubmitChanges();
                    });
            }
		}

        /// <summary>
        /// The article that the user wishes to edit.
        /// </summary>
        public ArticleViewModel SelectedArticle
        {
            get { return ArticleViewModel.Wrap(_blog, _navigation.SelectedArticle, _navigation); }
            set { _navigation.SelectedArticle = ArticleViewModel.Unwrap(value); }
        }

        /// <summary>
        /// True if an article is selected.
        /// </summary>
        public bool ArticleIsSelected
        {
            get { return _navigation.SelectedArticle != null; }
        }

        /// <summary>
        /// The command to delete an article. The article to be
        /// deleted is in the SelectedArticle property. This command
        /// is only enabled when SelectedArticle is set.
        /// </summary>
        public ICommand DeleteArticle
        {
            get
            {
                // Enable the delete command when an article is selected.
                return MakeCommand
                    .When(() => _navigation.SelectedArticle != null)
                    .Do(() =>
                     {
                         // Delete the arcile.
                         _blog.DeleteArticle(_navigation.SelectedArticle);

                         // Clear the selection.
                         _navigation.SelectedArticle = null;

                         // Save the user's changes.
                         _blog.SubmitChanges();
                     });
            }
        }
    }
}
