using Noteworthy.DataModel;
using Noteworthy.NavigationModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using UpdateControls.XAML;

namespace Noteworthy.ViewModel
{
    /// <summary>
    /// The behavior of a single article in the view. This class
    /// interprets the data model from the point of view of
    /// user navigation, and prepares it for the view.
    /// </summary>
    public class ArticleViewModel
    {
        private Blog _blog;
        private Article _article;
        private BlogNavigationModel _navigation;

        public ArticleViewModel(Blog blog, Article article, BlogNavigationModel navigation)
        {
            _blog = blog;
            _article = article;
            _navigation = navigation;
        }

        /// <summary>
        /// The title of the article.
        /// </summary>
        public string Title
        {
            get { return _article.Title; }
            // When the user sets the title, submit changes.
            set { _article.Title = value; _blog.SubmitChanges(); }
        }

        /// <summary>
        /// The name of the tag that is about to be created.
        /// </summary>
        public string NewTagName
        {
            get { return _navigation.NewTagName; }
            set { _navigation.NewTagName = value; }
        }

        /// <summary>
        /// The command to add a new tag to the article. The name
        /// of the tag is set in NewTagName. This command is only
        /// enabled if NewTagName is set.
        /// </summary>
        public ICommand AddNewTag
        {
            get
            {
                // Enable the command when a new tag name has been entered.
                // Add the tag to the article, and clear the new tag name.
                return MakeCommand
                    .When(() => !string.IsNullOrEmpty(_navigation.NewTagName))
                    .Do(() => 
                    {
                        _article.AddTag(_blog.GetOrCreateTagByName(_navigation.NewTagName));
                        _navigation.NewTagName = string.Empty;
                        // When the user adds a new tag, submit changes.
                        _blog.SubmitChanges();
                    });
            }
        }

        /// <summary>
        /// The list of tags assigned to this article.
        /// </summary>
        public IEnumerable<TagViewModel> Tags
        {
            get
            {
                // Create a view model for every tag in the article.
                return _article.ArticleTags
                    .Select(at => TagViewModel.Wrap(_blog, at.Tag, _navigation));
            }
        }

        /// <summary>
        /// The list of tags not assigned to this article.
        /// </summary>
        public IEnumerable<TagViewModel> AvailableTags
        {
            get
            {
                // Create a view model for every tag not in the article.
                return _blog.Tags
                    .Except(_article.ArticleTags.Select(at => at.Tag))
                    .Select(t => TagViewModel.Wrap(_blog, t, _navigation));
            }
        }

        /// <summary>
        /// The command to add existing tags to the article. The tags
        /// to add are selected from AvailableTags in the navigation model.
        /// This command is only enabled when at least one AvailableTag
        /// is selected.
        /// </summary>
        public ICommand AddTag
        {
            get
            {
                // Enable the command when any available tag is selected.
                // Add all of the selected tags to the article.
                return MakeCommand
                    .When(() => AvailableTags.Any(t => _navigation.TagIsSelected(TagViewModel.Unwrap(t))))
                    .Do(() =>
                    {
                        foreach (Tag tag in _navigation.SelectedTags)
                            _article.AddTag(tag);
                        // When the user adds a tag, save their changes.
                        _blog.SubmitChanges();
                    });
            }
        }

        /// <summary>
        /// The command to remove a tag from an article. The tags to
        /// be removed are selected from Tags in the navigation model.
        /// This command is only enabled when at least one Tag is selected.
        /// </summary>
        public ICommand RemoveTag
        {
            get
            {
                // Enable the command when any article tag is selected.
                // Remove all of the selected tags from the article.
                return MakeCommand
                    .When(() => Tags.Any(t => _navigation.TagIsSelected(TagViewModel.Unwrap(t))))
                    .Do(() =>
                    {
                        foreach (Tag tag in _navigation.SelectedTags)
                            _article.RemoveTag(_blog, tag);
                        // When the user removes a tag, save their changes.
                        _blog.SubmitChanges();
                    });
            }
        }

        ///////////////////////////////////////////////////////////
        // A view model that is attached to items in a list must
        // implement Equals and GetHashCode. This allows the view
        // to recognize the selected item in the list. Equals and
        // GetHashCode are based on the data model object that the
        // view model represents, not any other context object or
        // navigation object.
        ///////////////////////////////////////////////////////////

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            ArticleViewModel that = obj as ArticleViewModel;
            if (that == null)
                return false;
            return Object.Equals(this._article, that._article);
        }

        public override int GetHashCode()
        {
            return _article.GetHashCode();
        }

        ///////////////////////////////////////////////////////////
        // Create static methods to wrap and unwrap a data model
        // object in a view model. This allows the data model
        // object to be null when appropriate.
        ///////////////////////////////////////////////////////////

        public static ArticleViewModel Wrap(Blog blog, Article article, BlogNavigationModel navigation)
        {
            if (article == null)
                return null;
            else
                return new ArticleViewModel(blog, article, navigation);
        }

        public static Article Unwrap(ArticleViewModel viewModel)
        {
            if (viewModel == null)
                return null;
            else
                return viewModel._article;
        }
    }
}
