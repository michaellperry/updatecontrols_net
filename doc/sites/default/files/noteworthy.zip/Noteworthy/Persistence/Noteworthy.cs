namespace Noteworthy.Persistence
{
    partial class __Noteworthy_Sdf
    {
    }
}
