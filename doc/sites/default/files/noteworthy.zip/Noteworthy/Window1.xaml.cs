﻿using Noteworthy.DataModel;
using Noteworthy.NavigationModel;
using Noteworthy.ViewModel;
using System;
using System.Windows;
using UpdateControls.XAML;

namespace Noteworthy
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private Blog _blog;

        public Window1()
        {
            InitializeComponent();

            // Create a data model and a navigation model.
            _blog = new Blog();
            BlogNavigationModel navigationModel = new BlogNavigationModel();

            // Put them both in a view model, then wrap it for the view.
            this.DataContext = ForView.Wrap(new BlogViewModel(_blog, navigationModel));
        }

        protected override void OnClosed(EventArgs e)
        {
            // Dispose the data model to close the database connection.
            if (_blog != null)
                _blog.Dispose();
        }
    }
}
