﻿using System;
using System.Collections.Generic;
using System.Linq;
using UpdateControls;

namespace Noteworthy.DataModel
{
    public class Book
    {
        private Persistence.__Noteworthy_Sdf _context;
        private List<Article> _articles = new List<Article>();
        private List<Tag> _tags = new List<Tag>();

        private Independent _indArticles = new Independent();
        private Independent _indTags = new Independent();

        public Book(Persistence.__Noteworthy_Sdf context)
        {
            _context = context;
        }

        public void Load()
        {
            // Load all of the articles and tags from the context.
            _articles = _context.Articles.Select(a => new Article(this, a)).ToList();
            _tags = _context.Tags.Select(t => new Tag(this, t)).ToList();
        }

        public void SubmitChanges()
        {
            _context.SubmitChanges();
        }

        public IEnumerable<Article> Articles
        {
            get { _indArticles.OnGet(); return _articles; }
        }

        public IEnumerable<Tag> Tags
        {
            get { _indTags.OnGet(); return _tags; }
        }

        public Article NewArticle()
        {
            _indArticles.OnSet();
            Noteworthy.Persistence.Article persistentArticle = new Noteworthy.Persistence.Article();
            _context.Articles.InsertOnSubmit(persistentArticle);
            Article article = new Article(this, persistentArticle);
            _articles.Add(article);
            return article;
        }

        public void DeleteArticle(Article article)
        {
            _indArticles.OnSet();
            _context.Articles.DeleteOnSubmit(article.PersistentArticle);
            _articles.Remove(article);
        }

        public Tag NewTag()
        {
            _indTags.OnSet();
            Noteworthy.Persistence.Tag persistentTag = new Noteworthy.Persistence.Tag();
            _context.Tags.InsertOnSubmit(persistentTag);
            Tag tag = new Tag(this, persistentTag);
            _tags.Add(tag);
            return tag;
        }

        public void DeleteTag(Tag tag)
        {
            _indTags.OnSet();
            _context.Tags.DeleteOnSubmit(tag.PersistentTag);
            _tags.Remove(tag);
        }

        internal Tag TagFrom(Persistence.Tag persistentTag)
        {
            return _tags.Single(t => t.PersistentTag == persistentTag);
        }

        internal Article ArticleFrom(Persistence.Article persistentArticle)
        {
            return _articles.Single(t => t.PersistentArticle == persistentArticle);
        }
    }
}
