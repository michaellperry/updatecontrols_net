﻿using System;
using System.Collections.Generic;
using System.Linq;
using UpdateControls;

namespace Noteworthy.DataModel
{
    /// <summary>
    /// A blog is a collection of tagged articles. This class provides the business
    /// logic and encapsulates the database connection. All other classes have to
    /// go through the Blog to get to the database.
    /// </summary>
    public class Blog : IDisposable
    {
        private NoteworthyDataContext _dataContext = new NoteworthyDataContext(@"Data Source=.\DataModel\Noteworthy.sdf");

        // Cache the tags, since we read the list more often than it changes.
        private List<Tag> _tags;
        private Dependent _depTags;

        public Blog()
        {
            // The dependent executes the action during OnGet if it
            // is out of date.
            _depTags = new Dependent(() =>
            {
                // Cache the tags.
                _tags = _dataContext.Tags.ToList();
            });
        }

        public IEnumerable<Article> ArticlesByTag(Tag tag)
        {
            // Return all articles if no filter was supplied.
            // Return articles with a matching tag if a filter was supplied.
            if (tag == null)
                return _dataContext.Articles;
            else
                return _dataContext.Articles
                    .Where(a => a.ArticleTags
                        .Any(at => at.Tag == tag));
        }

        public Article NewArticle()
        {
            // Insert a new article into the table, and return it.
            Article article = new Article() { Title = "New Article" };
            _dataContext.Articles.InsertOnSubmit(article);
            return article;
        }

        public void DeleteArticle(Article article)
        {
            // Delete an article from the table.
            _dataContext.Articles.DeleteOnSubmit(article);
        }

        public void DeleteArticleTag(ArticleTag articleTag)
        {
            // Delete an article/tag association from the table.
            _dataContext.ArticleTags.DeleteOnSubmit(articleTag);
        }

        public Tag GetOrCreateTagByName(string newTagName)
        {
            // We are about to access the cache, so make sure
            // it is up to date first. Not only does this call
            // the action, but it also tracks dependency.
            // When the cache becomes out of date, the caller
            // also becomes out of date.
            _depTags.OnGet();

            // See if the tag already exists.
            Tag tag = _tags.Where(t => t.TagName == newTagName).FirstOrDefault();
            if (tag == null)
            {
                // Not there, so add it.
                tag = new Tag() { TagName = newTagName };
                _dataContext.Tags.InsertOnSubmit(tag);
            }

            return tag;
        }

        public IEnumerable<Tag> Tags
        {
            // Update the cache here, too. Same thing applies.
            // If the cache is already up to date, then the
            // action is not called and the database is not hit.
            // And the caller becomes dependent upon the cache,
            // so when it does go out of date, so will the caller.
            get { _depTags.OnGet(); return _tags; }
        }

        public void SubmitChanges()
        {
            _dataContext.SubmitChanges();
        }

        public void Dispose()
        {
            if (_dataContext != null)
                _dataContext.Dispose();
        }
    }
}
