using System;
using System.Collections.Generic;
using System.Linq;
using UpdateControls;

namespace Noteworthy.DataModel
{
    public class Tag
    {
        private Book _book;
        private Noteworthy.Persistence.Tag _persistentTag;

        private Independent _indName = new Independent();

        internal Tag(Book book, Noteworthy.Persistence.Tag persistentTag)
        {
            _book = book;
            _persistentTag = persistentTag;
        }

        internal Noteworthy.Persistence.Tag PersistentTag
        {
            get { return _persistentTag; }
        }

        public string Name
        {
            get { _indName.OnGet(); return _persistentTag.TagName; }
            set { _indName.OnSet(); _persistentTag.TagName = value; }
        }
    }
}
