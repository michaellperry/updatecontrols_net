using System.Collections.Generic;
using DataBindingSL.WithoutINPC.Models;

namespace DataBindingSL.WithoutINPC.ViewModels
{
    public class PersonViewModel
    {
        private Person _person;

		public PersonViewModel(Person person)
        {
            _person = person;
		}

        public string FirstName
        {
            get { return _person.FirstName; }
            set { _person.FirstName = value; }
        }

        public string LastName
        {
            get { return _person.LastName; }
            set { _person.LastName = value; }
        }

        public IEnumerable<DisplayOptionViewModel> DisplayAsOptions
        {
			get
			{
				yield return new DisplayOptionViewModel(_person, DisplayStrategies.FirstLast);
				yield return new DisplayOptionViewModel(_person, DisplayStrategies.LastFirst);
			}
        }

        public DisplayOptionViewModel DisplayAs
        {
			get { return new DisplayOptionViewModel(_person, _person.DisplayStrategy); }
            set { if (value != null) _person.DisplayStrategy = value.DisplayStrategy; }
        }
    }
}
