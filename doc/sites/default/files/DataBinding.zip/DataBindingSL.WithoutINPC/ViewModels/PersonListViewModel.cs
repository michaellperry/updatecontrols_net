﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using DataBindingSL.WithoutINPC.Models;
using DataBindingSL.WithoutINPC.Services;
using UpdateControls.XAML;

namespace DataBindingSL.WithoutINPC.ViewModels
{
    public class PersonListViewModel
    {
        private PersonList _personList;
        private Navigation _navigation;
		private IAddressBookService _addressBookService;

        public PersonListViewModel(PersonList personList, Navigation navigation, IAddressBookService addressBookService)
        {
            _personList = personList;
            _navigation = navigation;
			_addressBookService = addressBookService;
        }

		public void BeginLoad()
		{
			_addressBookService.BeginLoadPeople(people =>
			{
				foreach (Person person in people)
				{
					_personList.AddPerson(person);
				}
			});
		}

		public string Filter
		{
			get { return _navigation.Filter; }
			set { _navigation.Filter = value; }
		}

        public IEnumerable<PersonSummary> People
        {
            get
            {
                return
					from p in _personList.People
					where StartsWith(p.FirstName, _navigation.Filter) || StartsWith(p.LastName, _navigation.Filter)
                    select new PersonSummary(p);
            }
        }

        public PersonSummary SelectedPerson
        {
            get
            {
                return _navigation.SelectedPerson == null
                    ? null
                    : new PersonSummary(_navigation.SelectedPerson);
            }
            set
            {
                _navigation.SelectedPerson = value == null
                    ? null
					: value.GetPerson();
            }
        }

        public PersonViewModel PersonDetail
        {
            get
            {
                return _navigation.SelectedPerson == null
                    ? null
                    : new PersonViewModel(_navigation.SelectedPerson);
            }
        }

        public ICommand AddPerson
        {
            get
            {
                return MakeCommand
                    .Do(() =>
                    {
						Person newPerson = new Person();
						_personList.AddPerson(newPerson);
                        _navigation.SelectedPerson = newPerson;
                    });
            }
        }

        public ICommand DeletePerson
        {
            get
            {
                return MakeCommand
                    .When(() => _navigation.SelectedPerson != null)
                    .Do(() =>
                    {
                        _personList.DeletePerson(_navigation.SelectedPerson);
						_navigation.SelectedPerson = null;
                    });
            }
        }

		private static bool StartsWith(string test, string filter)
		{
			if (string.IsNullOrEmpty(filter))
				return true;
			if (string.IsNullOrEmpty(test))
				return false;
			return test.ToLower().StartsWith(filter.ToLower());
		}
    }
}
