using DataBindingSL.WithoutINPC.Models;

namespace DataBindingSL.WithoutINPC.ViewModels
{
    public class DisplayOptionViewModel
    {
        private Person _person;
        private IDisplayStrategy _displayStrategy;

        public DisplayOptionViewModel(Person person, IDisplayStrategy displayStrategy)
        {
            _person = person;
            _displayStrategy = displayStrategy;
        }

        public string Display
        {
            get { return _displayStrategy.Display(_person); }
        }

        public IDisplayStrategy DisplayStrategy
        {
            get { return _displayStrategy; }
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            DisplayOptionViewModel that = obj as DisplayOptionViewModel;
            if (that == null)
                return false;
            return object.Equals(_person, that._person) && object.Equals(_displayStrategy, that._displayStrategy);
        }

        public override int GetHashCode()
        {
            return _person.GetHashCode() * 37 + _displayStrategy.GetHashCode();
        }
    }
}
