using DataBindingSL.WithoutINPC.Models;

namespace DataBindingSL.WithoutINPC.ViewModels
{
    public class PersonSummary
    {
        private Person _person;

        public PersonSummary(Person person)
        {
            _person = person;
        }

		public Person GetPerson()
		{
			return _person;
		}

        public string FullName
        {
            get
            {
				return string.IsNullOrEmpty(_person.FirstName) && string.IsNullOrEmpty(_person.LastName)
					? "<New Person>"
					: _person.DisplayStrategy.Display(_person);
            }
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            PersonSummary that = obj as PersonSummary;
            if (that == null)
                return false;
            return _person.Equals(that._person);
        }

        public override int GetHashCode()
        {
            return _person.GetHashCode();
        }
    }
}
