﻿using System;
using System.Collections.Generic;
using DataBindingSL.WithoutINPC.Models;

namespace DataBindingSL.WithoutINPC.Services
{
	public interface IAddressBookService
	{
		void BeginLoadPeople(Action<List<Person>> callback);
	}
}
