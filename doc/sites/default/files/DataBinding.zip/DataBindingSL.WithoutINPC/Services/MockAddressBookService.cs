﻿using System;
using System.Collections.Generic;
using System.Threading;
using DataBindingSL.WithoutINPC.Models;

namespace DataBindingSL.WithoutINPC.Services
{
	public class MockAddressBookService : IAddressBookService
	{
		public void BeginLoadPeople(Action<List<Person>> callback)
		{
			ThreadPool.QueueUserWorkItem(o =>
			{
				Thread.Sleep(2000);
				List<Person> people = new List<Person>();
				people.Add(new Person() { FirstName = "Qui-Gon", LastName = "Jinn", DisplayStrategy = DisplayStrategies.LastFirst });
				people.Add(new Person() { FirstName = "Obi-Wan", LastName = "Kenobi", DisplayStrategy = DisplayStrategies.LastFirst });
				people.Add(new Person() { FirstName = "Shaak", LastName = "Ti", DisplayStrategy = DisplayStrategies.FirstLast });
				callback(people);
			});
		}
	}
}
