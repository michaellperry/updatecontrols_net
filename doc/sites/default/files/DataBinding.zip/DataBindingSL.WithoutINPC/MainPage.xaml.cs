﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using DataBindingSL.WithoutINPC.ViewModels;
using DataBindingSL.WithoutINPC.Models;
using UpdateControls.XAML;
using DataBindingSL.WithoutINPC.Services;

namespace DataBindingSL.WithoutINPC
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}

		private void MainPage_Loaded(object sender, RoutedEventArgs e)
		{
			PersonListViewModel viewModel = new PersonListViewModel(new PersonList(), new Navigation(), new MockAddressBookService());
			DataContext = ForView.Wrap(viewModel);
			viewModel.BeginLoad();
		}
	}
}
