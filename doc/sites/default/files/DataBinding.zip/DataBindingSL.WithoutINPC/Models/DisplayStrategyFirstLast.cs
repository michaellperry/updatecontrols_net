
namespace DataBindingSL.WithoutINPC.Models
{
    public class DisplayStrategyFirstLast : IDisplayStrategy
    {
        public string Display(Person person)
        {
            return string.Format("{0} {1}", person.FirstName, person.LastName);
        }
    }
}
