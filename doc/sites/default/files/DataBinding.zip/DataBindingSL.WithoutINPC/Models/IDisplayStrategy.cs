
namespace DataBindingSL.WithoutINPC.Models
{
    public interface IDisplayStrategy
    {
        string Display(Person person);
    }
}
