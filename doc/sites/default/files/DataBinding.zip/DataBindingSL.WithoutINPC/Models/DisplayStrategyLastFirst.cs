
namespace DataBindingSL.WithoutINPC.Models
{
    public class DisplayStrategyLastFirst : IDisplayStrategy
    {
        public string Display(Person person)
        {
            return string.Format("{0}, {1}", person.LastName, person.FirstName);
        }
    }
}
