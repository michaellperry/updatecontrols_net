﻿using System.Collections.Generic;
using UpdateControls;

namespace DataBindingSL.WithoutINPC.Models
{
    public class PersonList
    {
        private List<Person> _people = new List<Person>();
        private Independent _indPeople = new Independent();

        public IEnumerable<Person> People
        {
            get { _indPeople.OnGet(); return _people; }
        }

		public void AddPerson(Person person)
		{
			_indPeople.OnSet();
			_people.Add(person);
		}

		public void DeletePerson(Person person)
        {
            _indPeople.OnSet();
            _people.Remove(person);
        }
    }
}
