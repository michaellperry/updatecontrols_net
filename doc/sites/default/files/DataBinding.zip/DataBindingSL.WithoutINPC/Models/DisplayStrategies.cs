namespace DataBindingSL.WithoutINPC.Models
{
	public static class DisplayStrategies
	{
		public static readonly IDisplayStrategy FirstLast = new DisplayStrategyFirstLast();
		public static readonly IDisplayStrategy LastFirst = new DisplayStrategyLastFirst();
	}
}
