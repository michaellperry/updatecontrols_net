﻿namespace VMWorkshop.Domain
{
    public interface IUrlSerializer
    {
        string SerializeToUrlString();
    }
}
