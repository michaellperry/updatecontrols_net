﻿
namespace VMWorkshop.Domain
{
    public class ProductListView
    {
        public int ProductId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int QuantityOnHand { get; set; }
    }
}
