﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMWorkshop.Domain
{
    public interface IProductRepository
    {
        IList<Product> GetAll();

        Product GetProductById(int productId);

        void Persist(Product product);
    }
}
