﻿
namespace VMWorkshop.Domain
{
    public static class RequestHeaders
    {
        public const string Json = "application/json";
        public const string UrlEncodedForm = "application/x-www-form-urlencoded";
    }
}
