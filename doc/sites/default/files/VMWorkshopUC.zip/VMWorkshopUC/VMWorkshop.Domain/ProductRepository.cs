﻿using System;
using System.Collections.Generic;

namespace VMWorkshop.Domain
{
    public class ProductRepository : IProductRepository
    {
        public ProductRepository() { }

        public IList<Product> GetAll()
        {
            IList<Product> products = new List<Product>();
            for (int i = 0; i < 10; i++)
            {
                Product product = new Product();
                product.ProductId = i + 1;
                product.Title = string.Format("Product {0}", i + 1);
                product.Description = string.Format("Product description {0}", i + 1);
                product.QuantityOnHand = i + 1;
                product.ReleaseDate = DateTime.Today.AddDays(i);
                product.Price = i + 1;
                products.Add(product);
            }
            return products;
            /*
             * MLP: We can't use the builder because it gets the properties as it sets them.
             * This makes the repository dependent upon the properties that it's modifying,
             * which causes an infinite loop.
            IList<Product> products = Builder<Product>.CreateListOfSize(10).Build();
            return products;
             */
        }

        public Product GetProductById(int productId)
        {
            IList<Product> products = this.GetAll();
            return products[productId - 1];
        }

        public void Persist(Product product)
        {
            //do something here to persist changes
        }
    }
}
