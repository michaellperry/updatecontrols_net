﻿
namespace VMWorkshop.Domain
{
    public static class PostResponse
    {
        public const string Success = "\"success\"";
    }
}
