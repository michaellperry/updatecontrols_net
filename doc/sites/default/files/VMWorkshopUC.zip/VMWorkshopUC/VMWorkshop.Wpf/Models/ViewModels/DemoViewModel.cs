﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using AutoMapper;
using UpdateControls.XAML;
using VMWorkshop.Domain;
using VMWorkshop.Wpf.Models.NavigationModels;

namespace VMWorkshop.Wpf.Models.ViewModels
{
    public class DemoViewModel
    {
        // Private fields
        private IProductRepository _repository;
        private DemoNavigationModel _navigation = new DemoNavigationModel();

        // Public properties
        public bool IsUpdateMessageVisible
        {
            get { return _navigation.ProductIsUpdated; }
        }

        public IEnumerable<ProductViewModel> Products
        {
            get 
            {
                return _repository.GetAll()
                    .Select(p => new ProductViewModel(p));
            }
        }

        public ProductViewModel SelectedProduct
        {
            get { return _navigation.SelectedProduct == null ? null : new ProductViewModel(_navigation.SelectedProduct); }
            set { _navigation.SelectedProduct = value == null ? null : value.Product; }
        }

        // Constructor
        public DemoViewModel(IProductRepository repository)
        {
            this._repository = repository;
        }

        // Commands
        public ICommand Persist
        {
            get
            {
                return MakeCommand
                    .When(() => _navigation.SelectedProduct != null)
                    .Do(() =>
                    {
                        Product newProduct = _navigation.SelectedProduct;
                        Product oldProduct = this._repository.GetProductById(newProduct.ProductId);
                        oldProduct = Mapper.Map<Product, Product>(newProduct, oldProduct);
                        this._repository.Persist(oldProduct);

                        _navigation.SelectedProduct = null;
                        _navigation.ProductIsUpdated = true;
                    });
            }
        }
    }
}
