using System;
using VMWorkshop.Domain;

namespace VMWorkshop.Wpf.Models.ViewModels
{
    public class ProductViewModel
    {
        private Product _product;

        public ProductViewModel(Product product)
        {
            _product = product;
        }

        public string Title
        {
            get { return _product.Title; }
            set { _product.Title = value; }
        }

        public string Description
        {
            get { return _product.Description; }
            set { _product.Description = value; }
        }

        public int QuantityOnHand
        {
            get { return _product.QuantityOnHand; }
            set { _product.QuantityOnHand = value; }
        }

        public double Price
        {
            get { return _product.Price; }
            set { _product.Price = value; }
        }

        public DateTime ReleaseDate
        {
            get { return _product.ReleaseDate; }
            set { _product.ReleaseDate = value; }
        }

        public Product Product
        {
            get { return _product; }
        }
    }
}
