﻿using System.Windows;
using UpdateControls.XAML;
using VMWorkshop.Domain;
using VMWorkshop.Wpf.Models.ViewModels;

namespace VMWorkshop.Wpf.Views
{
    /// <summary>
    /// Interaction logic for Demo.xaml
    /// </summary>
    public partial class Demo : Window
    {
        private DemoViewModel _vm;

        public Demo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(Demo_Loaded);
        }

        void Demo_Loaded(object sender, RoutedEventArgs e)
        {
            this._vm = new DemoViewModel(new ProductRepository());
            this.DataContext = ForView.Wrap(this._vm);
        }
    }
}
