﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using AutoMapper;
using VMWorkshop.Domain;

namespace VMWorkshop.Wpf
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            this.Startup += new StartupEventHandler(App_Startup);
        }

        void App_Startup(object sender, StartupEventArgs e)
        {
            this.CreateMappings();
        }

        public void CreateMappings()
        {
            Mapper.CreateMap<Product, ProductListView>();

            Mapper.CreateMap<Product, Product>()
                .ForMember(dto => dto.CreatedBy, opt => opt.UseDestinationValue())
                .ForMember(dto => dto.CreatedOn, opt => opt.UseDestinationValue())
                .ForMember(dto => dto.ModifiedBy, opt => opt.UseDestinationValue())
                .ForMember(dto => dto.ModifiedOn, opt => opt.UseDestinationValue())
                ;
        }
    }
}
