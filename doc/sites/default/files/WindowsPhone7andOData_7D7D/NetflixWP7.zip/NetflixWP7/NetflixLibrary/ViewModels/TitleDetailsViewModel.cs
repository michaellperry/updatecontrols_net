﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NetflixLibrary.Models;

namespace NetflixLibrary.ViewModels
{
    public class TitleDetailsViewModel
    {
        private CatalogNavigationModel _navigation;

        public TitleDetailsViewModel(CatalogNavigationModel navigation)
        {
            _navigation = navigation;
        }

        public string Name
        {
            get
            {
                return _navigation.SelectedTitle == null
                    ? null
                    : _navigation.SelectedTitle.Name;
            }
        }

        public string Description
        {
            get
            {
                return _navigation.SelectedTitle == null
                    ? null
                    : _navigation.SelectedTitle.ShortSynopsis;
            }
        }
    }
}
