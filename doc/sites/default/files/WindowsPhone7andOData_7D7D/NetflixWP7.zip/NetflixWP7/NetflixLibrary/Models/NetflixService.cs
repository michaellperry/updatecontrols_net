﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace NetflixLibrary.Models
{

    /// <summary>
    /// There are no comments for NetflixCatalog in the schema.
    /// </summary>
    public partial class NetflixCatalog : global::System.Data.Services.Client.DataServiceContext
    {
        /// <summary>
        /// Initialize a new NetflixCatalog object.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public NetflixCatalog(global::System.Uri serviceRoot) :
            base(serviceRoot)
        {
            this.ResolveName = new global::System.Func<global::System.Type, string>(this.ResolveNameFromType);
            this.ResolveType = new global::System.Func<string, global::System.Type>(this.ResolveTypeFromName);
            this.OnContextCreated();
        }
        partial void OnContextCreated();
        /// <summary>
        /// Since the namespace configured for this service reference
        /// in Visual Studio is different from the one indicated in the
        /// server schema, use type-mappers to map between the two.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        protected global::System.Type ResolveTypeFromName(string typeName)
        {
            if (typeName.StartsWith("NetflixModel", global::System.StringComparison.Ordinal))
            {
                return this.GetType().Assembly.GetType(string.Concat("NetflixConsumer.ServiceReference1", typeName.Substring(12)), false);
            }
            return null;
        }
        /// <summary>
        /// Since the namespace configured for this service reference
        /// in Visual Studio is different from the one indicated in the
        /// server schema, use type-mappers to map between the two.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        protected string ResolveNameFromType(global::System.Type clientType)
        {
            if (clientType.Namespace.Equals("NetflixConsumer.ServiceReference1", global::System.StringComparison.Ordinal))
            {
                return string.Concat("NetflixModel.", clientType.Name);
            }
            return null;
        }
        /// <summary>
        /// There are no comments for Genres in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Data.Services.Client.DataServiceQuery<Genre> Genres
        {
            get
            {
                if ((this._Genres == null))
                {
                    this._Genres = base.CreateQuery<Genre>("Genres");
                }
                return this._Genres;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Data.Services.Client.DataServiceQuery<Genre> _Genres;
        /// <summary>
        /// There are no comments for Languages in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Data.Services.Client.DataServiceQuery<Language> Languages
        {
            get
            {
                if ((this._Languages == null))
                {
                    this._Languages = base.CreateQuery<Language>("Languages");
                }
                return this._Languages;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Data.Services.Client.DataServiceQuery<Language> _Languages;
        /// <summary>
        /// There are no comments for People in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Data.Services.Client.DataServiceQuery<Person> People
        {
            get
            {
                if ((this._People == null))
                {
                    this._People = base.CreateQuery<Person>("People");
                }
                return this._People;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Data.Services.Client.DataServiceQuery<Person> _People;
        /// <summary>
        /// There are no comments for TitleAudioFormats in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Data.Services.Client.DataServiceQuery<TitleAudioFormat> TitleAudioFormats
        {
            get
            {
                if ((this._TitleAudioFormats == null))
                {
                    this._TitleAudioFormats = base.CreateQuery<TitleAudioFormat>("TitleAudioFormats");
                }
                return this._TitleAudioFormats;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Data.Services.Client.DataServiceQuery<TitleAudioFormat> _TitleAudioFormats;
        /// <summary>
        /// There are no comments for TitleAwards in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Data.Services.Client.DataServiceQuery<TitleAward> TitleAwards
        {
            get
            {
                if ((this._TitleAwards == null))
                {
                    this._TitleAwards = base.CreateQuery<TitleAward>("TitleAwards");
                }
                return this._TitleAwards;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Data.Services.Client.DataServiceQuery<TitleAward> _TitleAwards;
        /// <summary>
        /// There are no comments for Titles in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Data.Services.Client.DataServiceQuery<Title> Titles
        {
            get
            {
                if ((this._Titles == null))
                {
                    this._Titles = base.CreateQuery<Title>("Titles");
                }
                return this._Titles;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Data.Services.Client.DataServiceQuery<Title> _Titles;
        /// <summary>
        /// There are no comments for TitleScreenFormats in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Data.Services.Client.DataServiceQuery<TitleScreenFormat> TitleScreenFormats
        {
            get
            {
                if ((this._TitleScreenFormats == null))
                {
                    this._TitleScreenFormats = base.CreateQuery<TitleScreenFormat>("TitleScreenFormats");
                }
                return this._TitleScreenFormats;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Data.Services.Client.DataServiceQuery<TitleScreenFormat> _TitleScreenFormats;
        /// <summary>
        /// There are no comments for Genres in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public void AddToGenres(Genre genre)
        {
            base.AddObject("Genres", genre);
        }
        /// <summary>
        /// There are no comments for Languages in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public void AddToLanguages(Language language)
        {
            base.AddObject("Languages", language);
        }
        /// <summary>
        /// There are no comments for People in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public void AddToPeople(Person person)
        {
            base.AddObject("People", person);
        }
        /// <summary>
        /// There are no comments for TitleAudioFormats in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public void AddToTitleAudioFormats(TitleAudioFormat titleAudioFormat)
        {
            base.AddObject("TitleAudioFormats", titleAudioFormat);
        }
        /// <summary>
        /// There are no comments for TitleAwards in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public void AddToTitleAwards(TitleAward titleAward)
        {
            base.AddObject("TitleAwards", titleAward);
        }
        /// <summary>
        /// There are no comments for Titles in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public void AddToTitles(Title title)
        {
            base.AddObject("Titles", title);
        }
        /// <summary>
        /// There are no comments for TitleScreenFormats in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public void AddToTitleScreenFormats(TitleScreenFormat titleScreenFormat)
        {
            base.AddObject("TitleScreenFormats", titleScreenFormat);
        }
    }
    /// <summary>
    /// There are no comments for NetflixModel.Genre in the schema.
    /// </summary>
    /// <KeyProperties>
    /// Name
    /// </KeyProperties>
    [global::System.Data.Services.Common.DataServiceKeyAttribute("Name")]
    public partial class Genre
    {
        /// <summary>
        /// Create a new Genre object.
        /// </summary>
        /// <param name="name">Initial value of Name.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static Genre CreateGenre(string name)
        {
            Genre genre = new Genre();
            genre.Name = name;
            return genre;
        }
        /// <summary>
        /// There are no comments for Property Name in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                this.OnNameChanging(value);
                this._Name = value;
                this.OnNameChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Name;
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        /// <summary>
        /// There are no comments for Titles in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Title> Titles
        {
            get
            {
                return this._Titles;
            }
            set
            {
                if ((value != null))
                {
                    this._Titles = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Title> _Titles = new global::System.Collections.ObjectModel.Collection<Title>();
    }
    /// <summary>
    /// There are no comments for NetflixModel.Language in the schema.
    /// </summary>
    /// <KeyProperties>
    /// Name
    /// </KeyProperties>
    [global::System.Data.Services.Common.DataServiceKeyAttribute("Name")]
    public partial class Language
    {
        /// <summary>
        /// Create a new Language object.
        /// </summary>
        /// <param name="name">Initial value of Name.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static Language CreateLanguage(string name)
        {
            Language language = new Language();
            language.Name = name;
            return language;
        }
        /// <summary>
        /// There are no comments for Property Name in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                this.OnNameChanging(value);
                this._Name = value;
                this.OnNameChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Name;
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        /// <summary>
        /// There are no comments for Titles in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Title> Titles
        {
            get
            {
                return this._Titles;
            }
            set
            {
                if ((value != null))
                {
                    this._Titles = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Title> _Titles = new global::System.Collections.ObjectModel.Collection<Title>();
    }
    /// <summary>
    /// There are no comments for NetflixModel.Person in the schema.
    /// </summary>
    /// <KeyProperties>
    /// Id
    /// </KeyProperties>
    [global::System.Data.Services.Common.DataServiceKeyAttribute("Id")]
    public partial class Person
    {
        /// <summary>
        /// Create a new Person object.
        /// </summary>
        /// <param name="ID">Initial value of Id.</param>
        /// <param name="name">Initial value of Name.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static Person CreatePerson(int ID, string name)
        {
            Person person = new Person();
            person.Id = ID;
            person.Name = name;
            return person;
        }
        /// <summary>
        /// There are no comments for Property Id in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                this.OnIdChanging(value);
                this._Id = value;
                this.OnIdChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private int _Id;
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        /// <summary>
        /// There are no comments for Property Name in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                this.OnNameChanging(value);
                this._Name = value;
                this.OnNameChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Name;
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        /// <summary>
        /// There are no comments for Awards in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<TitleAward> Awards
        {
            get
            {
                return this._Awards;
            }
            set
            {
                if ((value != null))
                {
                    this._Awards = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<TitleAward> _Awards = new global::System.Collections.ObjectModel.Collection<TitleAward>();
        /// <summary>
        /// There are no comments for TitlesActedIn in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Title> TitlesActedIn
        {
            get
            {
                return this._TitlesActedIn;
            }
            set
            {
                if ((value != null))
                {
                    this._TitlesActedIn = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Title> _TitlesActedIn = new global::System.Collections.ObjectModel.Collection<Title>();
        /// <summary>
        /// There are no comments for TitlesDirected in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Title> TitlesDirected
        {
            get
            {
                return this._TitlesDirected;
            }
            set
            {
                if ((value != null))
                {
                    this._TitlesDirected = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Title> _TitlesDirected = new global::System.Collections.ObjectModel.Collection<Title>();
    }
    /// <summary>
    /// There are no comments for NetflixModel.TitleAudioFormat in the schema.
    /// </summary>
    /// <KeyProperties>
    /// TitleId
    /// DeliveryFormat
    /// Language
    /// Format
    /// </KeyProperties>
    [global::System.Data.Services.Common.DataServiceKeyAttribute("TitleId", "DeliveryFormat", "Language", "Format")]
    public partial class TitleAudioFormat
    {
        /// <summary>
        /// Create a new TitleAudioFormat object.
        /// </summary>
        /// <param name="titleId">Initial value of TitleId.</param>
        /// <param name="deliveryFormat">Initial value of DeliveryFormat.</param>
        /// <param name="language">Initial value of Language.</param>
        /// <param name="format">Initial value of Format.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static TitleAudioFormat CreateTitleAudioFormat(string titleId, string deliveryFormat, string language, string format)
        {
            TitleAudioFormat titleAudioFormat = new TitleAudioFormat();
            titleAudioFormat.TitleId = titleId;
            titleAudioFormat.DeliveryFormat = deliveryFormat;
            titleAudioFormat.Language = language;
            titleAudioFormat.Format = format;
            return titleAudioFormat;
        }
        /// <summary>
        /// There are no comments for Property TitleId in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string TitleId
        {
            get
            {
                return this._TitleId;
            }
            set
            {
                this.OnTitleIdChanging(value);
                this._TitleId = value;
                this.OnTitleIdChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _TitleId;
        partial void OnTitleIdChanging(string value);
        partial void OnTitleIdChanged();
        /// <summary>
        /// There are no comments for Property DeliveryFormat in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string DeliveryFormat
        {
            get
            {
                return this._DeliveryFormat;
            }
            set
            {
                this.OnDeliveryFormatChanging(value);
                this._DeliveryFormat = value;
                this.OnDeliveryFormatChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _DeliveryFormat;
        partial void OnDeliveryFormatChanging(string value);
        partial void OnDeliveryFormatChanged();
        /// <summary>
        /// There are no comments for Property Language in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Language
        {
            get
            {
                return this._Language;
            }
            set
            {
                this.OnLanguageChanging(value);
                this._Language = value;
                this.OnLanguageChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Language;
        partial void OnLanguageChanging(string value);
        partial void OnLanguageChanged();
        /// <summary>
        /// There are no comments for Property Format in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Format
        {
            get
            {
                return this._Format;
            }
            set
            {
                this.OnFormatChanging(value);
                this._Format = value;
                this.OnFormatChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Format;
        partial void OnFormatChanging(string value);
        partial void OnFormatChanged();
        /// <summary>
        /// There are no comments for Title in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Title Title
        {
            get
            {
                return this._Title;
            }
            set
            {
                this._Title = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Title _Title;
    }
    /// <summary>
    /// There are no comments for NetflixModel.TitleAward in the schema.
    /// </summary>
    /// <KeyProperties>
    /// Id
    /// </KeyProperties>
    [global::System.Data.Services.Common.DataServiceKeyAttribute("Id")]
    public partial class TitleAward
    {
        /// <summary>
        /// Create a new TitleAward object.
        /// </summary>
        /// <param name="ID">Initial value of Id.</param>
        /// <param name="type">Initial value of Type.</param>
        /// <param name="category">Initial value of Category.</param>
        /// <param name="won">Initial value of Won.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static TitleAward CreateTitleAward(global::System.Guid ID, string type, string category, bool won)
        {
            TitleAward titleAward = new TitleAward();
            titleAward.Id = ID;
            titleAward.Type = type;
            titleAward.Category = category;
            titleAward.Won = won;
            return titleAward;
        }
        /// <summary>
        /// There are no comments for Property Id in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Guid Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                this.OnIdChanging(value);
                this._Id = value;
                this.OnIdChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Guid _Id;
        partial void OnIdChanging(global::System.Guid value);
        partial void OnIdChanged();
        /// <summary>
        /// There are no comments for Property Type in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Type
        {
            get
            {
                return this._Type;
            }
            set
            {
                this.OnTypeChanging(value);
                this._Type = value;
                this.OnTypeChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Type;
        partial void OnTypeChanging(string value);
        partial void OnTypeChanged();
        /// <summary>
        /// There are no comments for Property Category in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Category
        {
            get
            {
                return this._Category;
            }
            set
            {
                this.OnCategoryChanging(value);
                this._Category = value;
                this.OnCategoryChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Category;
        partial void OnCategoryChanging(string value);
        partial void OnCategoryChanged();
        /// <summary>
        /// There are no comments for Property Year in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<int> Year
        {
            get
            {
                return this._Year;
            }
            set
            {
                this.OnYearChanging(value);
                this._Year = value;
                this.OnYearChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<int> _Year;
        partial void OnYearChanging(global::System.Nullable<int> value);
        partial void OnYearChanged();
        /// <summary>
        /// There are no comments for Property Won in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public bool Won
        {
            get
            {
                return this._Won;
            }
            set
            {
                this.OnWonChanging(value);
                this._Won = value;
                this.OnWonChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _Won;
        partial void OnWonChanging(bool value);
        partial void OnWonChanged();
        /// <summary>
        /// There are no comments for Title in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Title Title
        {
            get
            {
                return this._Title;
            }
            set
            {
                this._Title = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Title _Title;
        /// <summary>
        /// There are no comments for Person in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Person Person
        {
            get
            {
                return this._Person;
            }
            set
            {
                this._Person = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Person _Person;
    }
    /// <summary>
    /// There are no comments for ComplexType NetflixModel.BoxArt in the schema.
    /// </summary>
    public partial class BoxArt
    {
        /// <summary>
        /// There are no comments for Property SmallUrl in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string SmallUrl
        {
            get
            {
                return this._SmallUrl;
            }
            set
            {
                this.OnSmallUrlChanging(value);
                this._SmallUrl = value;
                this.OnSmallUrlChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _SmallUrl;
        partial void OnSmallUrlChanging(string value);
        partial void OnSmallUrlChanged();
        /// <summary>
        /// There are no comments for Property MediumUrl in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string MediumUrl
        {
            get
            {
                return this._MediumUrl;
            }
            set
            {
                this.OnMediumUrlChanging(value);
                this._MediumUrl = value;
                this.OnMediumUrlChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _MediumUrl;
        partial void OnMediumUrlChanging(string value);
        partial void OnMediumUrlChanged();
        /// <summary>
        /// There are no comments for Property LargeUrl in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string LargeUrl
        {
            get
            {
                return this._LargeUrl;
            }
            set
            {
                this.OnLargeUrlChanging(value);
                this._LargeUrl = value;
                this.OnLargeUrlChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _LargeUrl;
        partial void OnLargeUrlChanging(string value);
        partial void OnLargeUrlChanged();
        /// <summary>
        /// There are no comments for Property HighDefinitionUrl in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string HighDefinitionUrl
        {
            get
            {
                return this._HighDefinitionUrl;
            }
            set
            {
                this.OnHighDefinitionUrlChanging(value);
                this._HighDefinitionUrl = value;
                this.OnHighDefinitionUrlChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _HighDefinitionUrl;
        partial void OnHighDefinitionUrlChanging(string value);
        partial void OnHighDefinitionUrlChanged();
    }
    /// <summary>
    /// There are no comments for ComplexType NetflixModel.InstantAvailability in the schema.
    /// </summary>
    public partial class InstantAvailability
    {
        /// <summary>
        /// Create a new InstantAvailability object.
        /// </summary>
        /// <param name="available">Initial value of Available.</param>
        /// <param name="highDefinitionAvailable">Initial value of HighDefinitionAvailable.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static InstantAvailability CreateInstantAvailability(bool available, bool highDefinitionAvailable)
        {
            InstantAvailability instantAvailability = new InstantAvailability();
            instantAvailability.Available = available;
            instantAvailability.HighDefinitionAvailable = highDefinitionAvailable;
            return instantAvailability;
        }
        /// <summary>
        /// There are no comments for Property Available in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public bool Available
        {
            get
            {
                return this._Available;
            }
            set
            {
                this.OnAvailableChanging(value);
                this._Available = value;
                this.OnAvailableChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _Available;
        partial void OnAvailableChanging(bool value);
        partial void OnAvailableChanged();
        /// <summary>
        /// There are no comments for Property AvailableFrom in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<global::System.DateTime> AvailableFrom
        {
            get
            {
                return this._AvailableFrom;
            }
            set
            {
                this.OnAvailableFromChanging(value);
                this._AvailableFrom = value;
                this.OnAvailableFromChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<global::System.DateTime> _AvailableFrom;
        partial void OnAvailableFromChanging(global::System.Nullable<global::System.DateTime> value);
        partial void OnAvailableFromChanged();
        /// <summary>
        /// There are no comments for Property AvailableTo in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<global::System.DateTime> AvailableTo
        {
            get
            {
                return this._AvailableTo;
            }
            set
            {
                this.OnAvailableToChanging(value);
                this._AvailableTo = value;
                this.OnAvailableToChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<global::System.DateTime> _AvailableTo;
        partial void OnAvailableToChanging(global::System.Nullable<global::System.DateTime> value);
        partial void OnAvailableToChanged();
        /// <summary>
        /// There are no comments for Property HighDefinitionAvailable in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public bool HighDefinitionAvailable
        {
            get
            {
                return this._HighDefinitionAvailable;
            }
            set
            {
                this.OnHighDefinitionAvailableChanging(value);
                this._HighDefinitionAvailable = value;
                this.OnHighDefinitionAvailableChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _HighDefinitionAvailable;
        partial void OnHighDefinitionAvailableChanging(bool value);
        partial void OnHighDefinitionAvailableChanged();
        /// <summary>
        /// There are no comments for Property Runtime in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<int> Runtime
        {
            get
            {
                return this._Runtime;
            }
            set
            {
                this.OnRuntimeChanging(value);
                this._Runtime = value;
                this.OnRuntimeChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<int> _Runtime;
        partial void OnRuntimeChanging(global::System.Nullable<int> value);
        partial void OnRuntimeChanged();
        /// <summary>
        /// There are no comments for Property Rating in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Rating
        {
            get
            {
                return this._Rating;
            }
            set
            {
                this.OnRatingChanging(value);
                this._Rating = value;
                this.OnRatingChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Rating;
        partial void OnRatingChanging(string value);
        partial void OnRatingChanged();
    }
    /// <summary>
    /// There are no comments for ComplexType NetflixModel.DeliveryFormatAvailability in the schema.
    /// </summary>
    public partial class DeliveryFormatAvailability
    {
        /// <summary>
        /// Create a new DeliveryFormatAvailability object.
        /// </summary>
        /// <param name="available">Initial value of Available.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static DeliveryFormatAvailability CreateDeliveryFormatAvailability(bool available)
        {
            DeliveryFormatAvailability deliveryFormatAvailability = new DeliveryFormatAvailability();
            deliveryFormatAvailability.Available = available;
            return deliveryFormatAvailability;
        }
        /// <summary>
        /// There are no comments for Property Available in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public bool Available
        {
            get
            {
                return this._Available;
            }
            set
            {
                this.OnAvailableChanging(value);
                this._Available = value;
                this.OnAvailableChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _Available;
        partial void OnAvailableChanging(bool value);
        partial void OnAvailableChanged();
        /// <summary>
        /// There are no comments for Property AvailableFrom in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<global::System.DateTime> AvailableFrom
        {
            get
            {
                return this._AvailableFrom;
            }
            set
            {
                this.OnAvailableFromChanging(value);
                this._AvailableFrom = value;
                this.OnAvailableFromChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<global::System.DateTime> _AvailableFrom;
        partial void OnAvailableFromChanging(global::System.Nullable<global::System.DateTime> value);
        partial void OnAvailableFromChanged();
        /// <summary>
        /// There are no comments for Property AvailableTo in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<global::System.DateTime> AvailableTo
        {
            get
            {
                return this._AvailableTo;
            }
            set
            {
                this.OnAvailableToChanging(value);
                this._AvailableTo = value;
                this.OnAvailableToChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<global::System.DateTime> _AvailableTo;
        partial void OnAvailableToChanging(global::System.Nullable<global::System.DateTime> value);
        partial void OnAvailableToChanged();
        /// <summary>
        /// There are no comments for Property Runtime in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<int> Runtime
        {
            get
            {
                return this._Runtime;
            }
            set
            {
                this.OnRuntimeChanging(value);
                this._Runtime = value;
                this.OnRuntimeChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<int> _Runtime;
        partial void OnRuntimeChanging(global::System.Nullable<int> value);
        partial void OnRuntimeChanged();
        /// <summary>
        /// There are no comments for Property Rating in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Rating
        {
            get
            {
                return this._Rating;
            }
            set
            {
                this.OnRatingChanging(value);
                this._Rating = value;
                this.OnRatingChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Rating;
        partial void OnRatingChanging(string value);
        partial void OnRatingChanged();
    }
    /// <summary>
    /// There are no comments for NetflixModel.Title in the schema.
    /// </summary>
    /// <KeyProperties>
    /// Id
    /// </KeyProperties>
    [global::System.Data.Services.Common.DataServiceKeyAttribute("Id")]
    public partial class Title
    {
        /// <summary>
        /// Create a new Title object.
        /// </summary>
        /// <param name="ID">Initial value of Id.</param>
        /// <param name="dateModified">Initial value of DateModified.</param>
        /// <param name="type">Initial value of Type.</param>
        /// <param name="boxArt">Initial value of BoxArt.</param>
        /// <param name="shortName">Initial value of ShortName.</param>
        /// <param name="name">Initial value of Name.</param>
        /// <param name="instant">Initial value of Instant.</param>
        /// <param name="dvd">Initial value of Dvd.</param>
        /// <param name="bluRay">Initial value of BluRay.</param>
        /// <param name="tinyUrl">Initial value of TinyUrl.</param>
        /// <param name="netflixApiId">Initial value of NetflixApiId.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static Title CreateTitle(string ID, global::System.DateTime dateModified, string type, BoxArt boxArt, string shortName, string name, InstantAvailability instant, DeliveryFormatAvailability dvd, DeliveryFormatAvailability bluRay, string tinyUrl, string netflixApiId)
        {
            Title title = new Title();
            title.Id = ID;
            title.DateModified = dateModified;
            title.Type = type;
            if ((boxArt == null))
            {
                throw new global::System.ArgumentNullException("boxArt");
            }
            title.BoxArt = boxArt;
            title.ShortName = shortName;
            title.Name = name;
            if ((instant == null))
            {
                throw new global::System.ArgumentNullException("instant");
            }
            title.Instant = instant;
            if ((dvd == null))
            {
                throw new global::System.ArgumentNullException("dvd");
            }
            title.Dvd = dvd;
            if ((bluRay == null))
            {
                throw new global::System.ArgumentNullException("bluRay");
            }
            title.BluRay = bluRay;
            title.TinyUrl = tinyUrl;
            title.NetflixApiId = netflixApiId;
            return title;
        }
        /// <summary>
        /// There are no comments for Property Id in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                this.OnIdChanging(value);
                this._Id = value;
                this.OnIdChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Id;
        partial void OnIdChanging(string value);
        partial void OnIdChanged();
        /// <summary>
        /// There are no comments for Property Synopsis in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Synopsis
        {
            get
            {
                return this._Synopsis;
            }
            set
            {
                this.OnSynopsisChanging(value);
                this._Synopsis = value;
                this.OnSynopsisChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Synopsis;
        partial void OnSynopsisChanging(string value);
        partial void OnSynopsisChanged();
        /// <summary>
        /// There are no comments for Property ShortSynopsis in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string ShortSynopsis
        {
            get
            {
                return this._ShortSynopsis;
            }
            set
            {
                this.OnShortSynopsisChanging(value);
                this._ShortSynopsis = value;
                this.OnShortSynopsisChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _ShortSynopsis;
        partial void OnShortSynopsisChanging(string value);
        partial void OnShortSynopsisChanged();
        /// <summary>
        /// There are no comments for Property AverageRating in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<double> AverageRating
        {
            get
            {
                return this._AverageRating;
            }
            set
            {
                this.OnAverageRatingChanging(value);
                this._AverageRating = value;
                this.OnAverageRatingChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<double> _AverageRating;
        partial void OnAverageRatingChanging(global::System.Nullable<double> value);
        partial void OnAverageRatingChanged();
        /// <summary>
        /// There are no comments for Property ReleaseYear in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<int> ReleaseYear
        {
            get
            {
                return this._ReleaseYear;
            }
            set
            {
                this.OnReleaseYearChanging(value);
                this._ReleaseYear = value;
                this.OnReleaseYearChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<int> _ReleaseYear;
        partial void OnReleaseYearChanging(global::System.Nullable<int> value);
        partial void OnReleaseYearChanged();
        /// <summary>
        /// There are no comments for Property Url in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Url
        {
            get
            {
                return this._Url;
            }
            set
            {
                this.OnUrlChanging(value);
                this._Url = value;
                this.OnUrlChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Url;
        partial void OnUrlChanging(string value);
        partial void OnUrlChanged();
        /// <summary>
        /// There are no comments for Property Runtime in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Nullable<int> Runtime
        {
            get
            {
                return this._Runtime;
            }
            set
            {
                this.OnRuntimeChanging(value);
                this._Runtime = value;
                this.OnRuntimeChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Nullable<int> _Runtime;
        partial void OnRuntimeChanging(global::System.Nullable<int> value);
        partial void OnRuntimeChanged();
        /// <summary>
        /// There are no comments for Property Rating in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Rating
        {
            get
            {
                return this._Rating;
            }
            set
            {
                this.OnRatingChanging(value);
                this._Rating = value;
                this.OnRatingChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Rating;
        partial void OnRatingChanging(string value);
        partial void OnRatingChanged();
        /// <summary>
        /// There are no comments for Property DateModified in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.DateTime DateModified
        {
            get
            {
                return this._DateModified;
            }
            set
            {
                this.OnDateModifiedChanging(value);
                this._DateModified = value;
                this.OnDateModifiedChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.DateTime _DateModified;
        partial void OnDateModifiedChanging(global::System.DateTime value);
        partial void OnDateModifiedChanged();
        /// <summary>
        /// There are no comments for Property Type in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Type
        {
            get
            {
                return this._Type;
            }
            set
            {
                this.OnTypeChanging(value);
                this._Type = value;
                this.OnTypeChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Type;
        partial void OnTypeChanging(string value);
        partial void OnTypeChanged();
        /// <summary>
        /// There are no comments for Property BoxArt in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public BoxArt BoxArt
        {
            get
            {
                if (((this._BoxArt == null)
                            && (this._BoxArtInitialized != true)))
                {
                    this._BoxArt = new BoxArt();
                    this._BoxArtInitialized = true;
                }
                return this._BoxArt;
            }
            set
            {
                this.OnBoxArtChanging(value);
                this._BoxArt = value;
                this._BoxArtInitialized = true;
                this.OnBoxArtChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private BoxArt _BoxArt;
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _BoxArtInitialized;
        partial void OnBoxArtChanging(BoxArt value);
        partial void OnBoxArtChanged();
        /// <summary>
        /// There are no comments for Property ShortName in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string ShortName
        {
            get
            {
                return this._ShortName;
            }
            set
            {
                this.OnShortNameChanging(value);
                this._ShortName = value;
                this.OnShortNameChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _ShortName;
        partial void OnShortNameChanging(string value);
        partial void OnShortNameChanged();
        /// <summary>
        /// There are no comments for Property Name in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                this.OnNameChanging(value);
                this._Name = value;
                this.OnNameChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Name;
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        /// <summary>
        /// There are no comments for Property Instant in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public InstantAvailability Instant
        {
            get
            {
                if (((this._Instant == null)
                            && (this._InstantInitialized != true)))
                {
                    this._Instant = new InstantAvailability();
                    this._InstantInitialized = true;
                }
                return this._Instant;
            }
            set
            {
                this.OnInstantChanging(value);
                this._Instant = value;
                this._InstantInitialized = true;
                this.OnInstantChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private InstantAvailability _Instant;
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _InstantInitialized;
        partial void OnInstantChanging(InstantAvailability value);
        partial void OnInstantChanged();
        /// <summary>
        /// There are no comments for Property Dvd in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public DeliveryFormatAvailability Dvd
        {
            get
            {
                if (((this._Dvd == null)
                            && (this._DvdInitialized != true)))
                {
                    this._Dvd = new DeliveryFormatAvailability();
                    this._DvdInitialized = true;
                }
                return this._Dvd;
            }
            set
            {
                this.OnDvdChanging(value);
                this._Dvd = value;
                this._DvdInitialized = true;
                this.OnDvdChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private DeliveryFormatAvailability _Dvd;
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _DvdInitialized;
        partial void OnDvdChanging(DeliveryFormatAvailability value);
        partial void OnDvdChanged();
        /// <summary>
        /// There are no comments for Property BluRay in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public DeliveryFormatAvailability BluRay
        {
            get
            {
                if (((this._BluRay == null)
                            && (this._BluRayInitialized != true)))
                {
                    this._BluRay = new DeliveryFormatAvailability();
                    this._BluRayInitialized = true;
                }
                return this._BluRay;
            }
            set
            {
                this.OnBluRayChanging(value);
                this._BluRay = value;
                this._BluRayInitialized = true;
                this.OnBluRayChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private DeliveryFormatAvailability _BluRay;
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private bool _BluRayInitialized;
        partial void OnBluRayChanging(DeliveryFormatAvailability value);
        partial void OnBluRayChanged();
        /// <summary>
        /// There are no comments for Property TinyUrl in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string TinyUrl
        {
            get
            {
                return this._TinyUrl;
            }
            set
            {
                this.OnTinyUrlChanging(value);
                this._TinyUrl = value;
                this.OnTinyUrlChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _TinyUrl;
        partial void OnTinyUrlChanging(string value);
        partial void OnTinyUrlChanged();
        /// <summary>
        /// There are no comments for Property WebsiteUrl in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string WebsiteUrl
        {
            get
            {
                return this._WebsiteUrl;
            }
            set
            {
                this.OnWebsiteUrlChanging(value);
                this._WebsiteUrl = value;
                this.OnWebsiteUrlChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _WebsiteUrl;
        partial void OnWebsiteUrlChanging(string value);
        partial void OnWebsiteUrlChanged();
        /// <summary>
        /// There are no comments for Property NetflixApiId in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string NetflixApiId
        {
            get
            {
                return this._NetflixApiId;
            }
            set
            {
                this.OnNetflixApiIdChanging(value);
                this._NetflixApiId = value;
                this.OnNetflixApiIdChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _NetflixApiId;
        partial void OnNetflixApiIdChanging(string value);
        partial void OnNetflixApiIdChanged();
        /// <summary>
        /// There are no comments for AudioFormats in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<TitleAudioFormat> AudioFormats
        {
            get
            {
                return this._AudioFormats;
            }
            set
            {
                if ((value != null))
                {
                    this._AudioFormats = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<TitleAudioFormat> _AudioFormats = new global::System.Collections.ObjectModel.Collection<TitleAudioFormat>();
        /// <summary>
        /// There are no comments for Awards in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<TitleAward> Awards
        {
            get
            {
                return this._Awards;
            }
            set
            {
                if ((value != null))
                {
                    this._Awards = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<TitleAward> _Awards = new global::System.Collections.ObjectModel.Collection<TitleAward>();
        /// <summary>
        /// There are no comments for Disc in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Title Disc
        {
            get
            {
                return this._Disc;
            }
            set
            {
                this._Disc = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Title _Disc;
        /// <summary>
        /// There are no comments for Movie in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Title Movie
        {
            get
            {
                return this._Movie;
            }
            set
            {
                this._Movie = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Title _Movie;
        /// <summary>
        /// There are no comments for Season in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Title Season
        {
            get
            {
                return this._Season;
            }
            set
            {
                this._Season = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Title _Season;
        /// <summary>
        /// There are no comments for Series in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Title Series
        {
            get
            {
                return this._Series;
            }
            set
            {
                this._Series = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Title _Series;
        /// <summary>
        /// There are no comments for ScreenFormats in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<TitleScreenFormat> ScreenFormats
        {
            get
            {
                return this._ScreenFormats;
            }
            set
            {
                if ((value != null))
                {
                    this._ScreenFormats = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<TitleScreenFormat> _ScreenFormats = new global::System.Collections.ObjectModel.Collection<TitleScreenFormat>();
        /// <summary>
        /// There are no comments for Cast in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Person> Cast
        {
            get
            {
                return this._Cast;
            }
            set
            {
                if ((value != null))
                {
                    this._Cast = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Person> _Cast = new global::System.Collections.ObjectModel.Collection<Person>();
        /// <summary>
        /// There are no comments for Languages in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Language> Languages
        {
            get
            {
                return this._Languages;
            }
            set
            {
                if ((value != null))
                {
                    this._Languages = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Language> _Languages = new global::System.Collections.ObjectModel.Collection<Language>();
        /// <summary>
        /// There are no comments for Directors in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Person> Directors
        {
            get
            {
                return this._Directors;
            }
            set
            {
                if ((value != null))
                {
                    this._Directors = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Person> _Directors = new global::System.Collections.ObjectModel.Collection<Person>();
        /// <summary>
        /// There are no comments for Genres in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public global::System.Collections.ObjectModel.Collection<Genre> Genres
        {
            get
            {
                return this._Genres;
            }
            set
            {
                if ((value != null))
                {
                    this._Genres = value;
                }
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private global::System.Collections.ObjectModel.Collection<Genre> _Genres = new global::System.Collections.ObjectModel.Collection<Genre>();
    }
    /// <summary>
    /// There are no comments for NetflixModel.TitleScreenFormat in the schema.
    /// </summary>
    /// <KeyProperties>
    /// TitleId
    /// DeliveryFormat
    /// Format
    /// </KeyProperties>
    [global::System.Data.Services.Common.DataServiceKeyAttribute("TitleId", "DeliveryFormat", "Format")]
    public partial class TitleScreenFormat
    {
        /// <summary>
        /// Create a new TitleScreenFormat object.
        /// </summary>
        /// <param name="titleId">Initial value of TitleId.</param>
        /// <param name="deliveryFormat">Initial value of DeliveryFormat.</param>
        /// <param name="format">Initial value of Format.</param>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public static TitleScreenFormat CreateTitleScreenFormat(string titleId, string deliveryFormat, string format)
        {
            TitleScreenFormat titleScreenFormat = new TitleScreenFormat();
            titleScreenFormat.TitleId = titleId;
            titleScreenFormat.DeliveryFormat = deliveryFormat;
            titleScreenFormat.Format = format;
            return titleScreenFormat;
        }
        /// <summary>
        /// There are no comments for Property TitleId in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string TitleId
        {
            get
            {
                return this._TitleId;
            }
            set
            {
                this.OnTitleIdChanging(value);
                this._TitleId = value;
                this.OnTitleIdChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _TitleId;
        partial void OnTitleIdChanging(string value);
        partial void OnTitleIdChanged();
        /// <summary>
        /// There are no comments for Property DeliveryFormat in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string DeliveryFormat
        {
            get
            {
                return this._DeliveryFormat;
            }
            set
            {
                this.OnDeliveryFormatChanging(value);
                this._DeliveryFormat = value;
                this.OnDeliveryFormatChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _DeliveryFormat;
        partial void OnDeliveryFormatChanging(string value);
        partial void OnDeliveryFormatChanged();
        /// <summary>
        /// There are no comments for Property Format in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public string Format
        {
            get
            {
                return this._Format;
            }
            set
            {
                this.OnFormatChanging(value);
                this._Format = value;
                this.OnFormatChanged();
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private string _Format;
        partial void OnFormatChanging(string value);
        partial void OnFormatChanged();
        /// <summary>
        /// There are no comments for Title in the schema.
        /// </summary>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        public Title Title
        {
            get
            {
                return this._Title;
            }
            set
            {
                this._Title = value;
            }
        }
        [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Services.Design", "1.0.0")]
        private Title _Title;
    }
}
