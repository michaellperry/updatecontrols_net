﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using System.Data.Services.Client;
using UpdateControls;

namespace NetflixLibrary.Models
{
    public class Catalog
    {
        private List<Title> _titles = new List<Title>();
        private Independent _indTitles = new Independent();

        public IEnumerable<Title> Titles
        {
            get
            {
                lock (this)
                {
                    _indTitles.OnGet();
                    return _titles;
                }
            }
        }

        public void Download()
        {
            var service = new NetflixCatalog(new Uri("http://odata.netflix.com/Catalog/"));
            var query = service.Titles
                .Where(title => title.Rating == "PG" && title.ReleaseYear == 1983)
                .OrderByDescending(title => title.AverageRating)
                .Take(20) as DataServiceQuery<Title>;
            query.BeginExecute(a =>
            {
                lock (this)
                {
                    _indTitles.OnSet();
                    _titles = query.EndExecute(a).ToList();
                }
            }, null);
        }
    }
}
