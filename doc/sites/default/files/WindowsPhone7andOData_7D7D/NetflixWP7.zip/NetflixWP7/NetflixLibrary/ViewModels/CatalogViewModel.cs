﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NetflixLibrary.Models;
using System.Collections.Generic;
using System.Linq;

namespace NetflixLibrary.ViewModels
{
    public class CatalogViewModel
    {
        private Catalog _catalog;
        private CatalogNavigationModel _navigation;

        public CatalogViewModel(Catalog catalog, CatalogNavigationModel navigation)
        {
            _catalog = catalog;
            _navigation = navigation;
        }

        public IEnumerable<TitleSummaryViewModel> Titles
        {
            get
            {
                return _catalog.Titles.Select(title => new TitleSummaryViewModel(title));
            }
        }

        public TitleSummaryViewModel SelectedTitle
        {
            get
            {
                return _navigation.SelectedTitle == null
                    ? null :
                    new TitleSummaryViewModel(_navigation.SelectedTitle);
            }
            set
            {
            	_navigation.SelectedTitle = value == null
                    ? null
                    : value.Title;
            }
        }

        public void Download()
        {
            _catalog.Download();
        }
    }
}
