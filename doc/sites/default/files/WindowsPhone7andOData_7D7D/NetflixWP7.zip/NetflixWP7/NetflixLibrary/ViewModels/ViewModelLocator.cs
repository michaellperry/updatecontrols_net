﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NetflixLibrary.Models;
using UpdateControls.XAML;

namespace NetflixLibrary.ViewModels
{
    public class ViewModelLocator
    {
        private CatalogViewModel _catalogViewModel;
        private TitleDetailsViewModel _titleDetailsViewModel;

        public ViewModelLocator()
        {
            CatalogNavigationModel navigation = new CatalogNavigationModel();
            _catalogViewModel = new CatalogViewModel(new Catalog(), navigation);
            _titleDetailsViewModel = new TitleDetailsViewModel(navigation);
        }

        public object CatalogViewModel
        {
            get { return ForView.Wrap(_catalogViewModel); }
        }

        public object TitleDetailsViewModel
        {
            get { return ForView.Wrap(_titleDetailsViewModel); }
        }
    }
}
