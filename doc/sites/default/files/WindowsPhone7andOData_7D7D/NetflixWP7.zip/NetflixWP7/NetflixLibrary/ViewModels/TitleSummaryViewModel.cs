﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NetflixLibrary.Models;

namespace NetflixLibrary.ViewModels
{
    public class TitleSummaryViewModel
    {
        private Title _title;

        public TitleSummaryViewModel(Title title)
        {
            _title = title;
        }

        public Title Title
        {
            get { return _title; }
        }

        public string Name
        {
            get { return _title.Name; }
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            TitleSummaryViewModel that = obj as TitleSummaryViewModel;
            if (that == null)
                return false;
            return this._title == that._title;
        }

        public override int GetHashCode()
        {
            return _title.GetHashCode();
        }
    }
}
