using System;

namespace DataBoundMenus
{
    public interface IFileHandler
    {
        void Open(string fileName);
    }
}
