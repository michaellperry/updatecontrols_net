using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CaseFile
{
    static class Program
    {
        private static Document _document = new Document();
        private static int _formCount = 0;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            OpenForm();
            Application.Run();
        }

        public static void OpenForm()
        {
            MainForm mainForm = new MainForm(_document);
            mainForm.FormClosed += new FormClosedEventHandler(mainForm_FormClosed);
            ++_formCount;
            mainForm.Show();
        }

        private static void mainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            --_formCount;
            if (_formCount == 0)
                Application.ExitThread();
        }
    }
}