namespace CaseFile
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.newWindowButton = new System.Windows.Forms.Button();
            this.deleteButton = new UpdateControls.Themes.Forms.ThemedButton();
            this.editButton = new UpdateControls.Themes.Forms.ThemedButton();
            this.addButton = new UpdateControls.Themes.Forms.ThemedButton();
            this.personListView = new UpdateControls.Forms.UpdateListView();
            this.nameColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.ageColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.occupationColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.personDetailDeck = new UpdateControls.Themes.Forms.ThemedTabDeck(this.components);
            this.occupationImageList = new System.Windows.Forms.ImageList(this.components);
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.newWindowButton);
            this.splitContainer1.Panel1.Controls.Add(this.deleteButton);
            this.splitContainer1.Panel1.Controls.Add(this.editButton);
            this.splitContainer1.Panel1.Controls.Add(this.addButton);
            this.splitContainer1.Panel1.Controls.Add(this.personListView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.personDetailDeck);
            this.splitContainer1.Size = new System.Drawing.Size(555, 201);
            this.splitContainer1.SplitterDistance = 294;
            this.splitContainer1.TabIndex = 0;
            // 
            // newWindowButton
            // 
            this.newWindowButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.newWindowButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newWindowButton.ForeColor = System.Drawing.SystemColors.Control;
            this.newWindowButton.Image = ((System.Drawing.Image)(resources.GetObject("newWindowButton.Image")));
            this.newWindowButton.Location = new System.Drawing.Point(3, 176);
            this.newWindowButton.Name = "newWindowButton";
            this.newWindowButton.Size = new System.Drawing.Size(22, 22);
            this.newWindowButton.TabIndex = 4;
            this.newWindowButton.Click += new System.EventHandler(this.newWindowButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.deleteButton.Location = new System.Drawing.Point(214, 166);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(75, 23);
            this.deleteButton.TabIndex = 3;
            this.deleteButton.Text = "&Delete";
            this.deleteButton.Theme = null;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            this.deleteButton.GetEnabled += new UpdateControls.Forms.GetBoolDelegate(this.ButtonEnabled);
            // 
            // editButton
            // 
            this.editButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.editButton.Location = new System.Drawing.Point(133, 166);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(75, 23);
            this.editButton.TabIndex = 2;
            this.editButton.Text = "&Edit";
            this.editButton.Theme = null;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            this.editButton.GetEnabled += new UpdateControls.Forms.GetBoolDelegate(this.ButtonEnabled);
            // 
            // addButton
            // 
            this.addButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addButton.Location = new System.Drawing.Point(52, 166);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 23);
            this.addButton.TabIndex = 1;
            this.addButton.Text = "&Add";
            this.addButton.Theme = null;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // personListView
            // 
            this.personListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.personListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.nameColumnHeader,
            this.ageColumnHeader,
            this.occupationColumnHeader});
            this.personListView.HideSelection = false;
            this.personListView.Location = new System.Drawing.Point(0, 0);
            this.personListView.Name = "personListView";
            this.personListView.Size = new System.Drawing.Size(294, 160);
            this.personListView.TabIndex = 0;
            this.personListView.UseCompatibleStateImageBehavior = false;
            this.personListView.View = System.Windows.Forms.View.Details;
            this.personListView.GetItemText += new UpdateControls.Forms.GetObjectStringDelegate(this.personListView_GetItemText);
            this.personListView.GetItems += new UpdateControls.Forms.GetCollectionDelegate(this.personListView_GetItems);
            this.personListView.GetSubItems += new UpdateControls.Forms.GetObjectCollectionDelegate(this.personListView_GetSubItems);
            this.personListView.DoubleClick += new System.EventHandler(this.editButton_Click);
            // 
            // nameColumnHeader
            // 
            this.nameColumnHeader.Text = "Name";
            this.nameColumnHeader.Width = 145;
            // 
            // ageColumnHeader
            // 
            this.ageColumnHeader.Text = "Age";
            // 
            // occupationColumnHeader
            // 
            this.occupationColumnHeader.Text = "Occupation";
            this.occupationColumnHeader.Width = 80;
            // 
            // personDetailDeck
            // 
            this.personDetailDeck.CloseTheme = null;
            this.personDetailDeck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.personDetailDeck.HasImages = true;
            this.personDetailDeck.Location = new System.Drawing.Point(0, 0);
            this.personDetailDeck.Name = "personDetailDeck";
            this.personDetailDeck.Size = new System.Drawing.Size(257, 201);
            this.personDetailDeck.TabIndex = 0;
            this.personDetailDeck.Text = "themedTabDeck1";
            this.personDetailDeck.Theme = null;
            this.personDetailDeck.GetItemText += new UpdateControls.Forms.GetObjectStringDelegate(this.personDetailDeck_GetItemText);
            this.personDetailDeck.GetItems += new UpdateControls.Forms.GetCollectionDelegate(this.personDetailDeck_GetItems);
            this.personDetailDeck.SetTabPosition += new UpdateControls.Themes.SetObjectIntegerDelegate(this.personDetailDeck_SetTabPosition);
            this.personDetailDeck.CreateContent += new UpdateControls.Themes.CreateControlDelegate(this.personDetailDeck_CreateContent);
            this.personDetailDeck.GetItemImage += new UpdateControls.Themes.GetObjectImageDelegate(this.personDetailDeck_GetItemImage);
            this.personDetailDeck.CloseTab += new UpdateControls.Forms.ObjectActionDelegate(this.personDetailDeck_CloseTab);
            // 
            // occupationImageList
            // 
            this.occupationImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("occupationImageList.ImageStream")));
            this.occupationImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.occupationImageList.Images.SetKeyName(0, "Doctor");
            this.occupationImageList.Images.SetKeyName(1, "Law Enforcement");
            this.occupationImageList.Images.SetKeyName(2, "Nurse");
            this.occupationImageList.Images.SetKeyName(3, "Software Developer");
            this.occupationImageList.Images.SetKeyName(4, "Baker");
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 201);
            this.Controls.Add(this.splitContainer1);
            this.Name = "MainForm";
            this.Text = "Case File";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private UpdateControls.Forms.UpdateListView personListView;
        private UpdateControls.Themes.Forms.ThemedButton addButton;
        private UpdateControls.Themes.Forms.ThemedButton deleteButton;
        private UpdateControls.Themes.Forms.ThemedButton editButton;
        private UpdateControls.Themes.Forms.ThemedTabDeck personDetailDeck;
        private System.Windows.Forms.ColumnHeader nameColumnHeader;
        private System.Windows.Forms.ColumnHeader ageColumnHeader;
        private System.Windows.Forms.ColumnHeader occupationColumnHeader;
        private System.Windows.Forms.Button newWindowButton;
        private System.Windows.Forms.ImageList occupationImageList;
    }
}

