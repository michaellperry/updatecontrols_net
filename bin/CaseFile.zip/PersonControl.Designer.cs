namespace CaseFile
{
    partial class PersonControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PersonControl));
            this.label1 = new System.Windows.Forms.Label();
            this.firstNameTextBox = new UpdateControls.Forms.UpdateTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lastNameTextBox = new UpdateControls.Forms.UpdateTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.occupationComboBox = new UpdateControls.Forms.UpdateComboBox();
            this.ageTextBox = new UpdateControls.Forms.UpdateTextBox();
            this.updateErrorProvider = new UpdateControls.Forms.UpdateErrorProvider(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(79, 3);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.RealTime = true;
            this.firstNameTextBox.Size = new System.Drawing.Size(167, 20);
            this.firstNameTextBox.TabIndex = 1;
            this.firstNameTextBox.GetText += new UpdateControls.Forms.GetStringDelegate(this.firstNameTextBox_GetText);
            this.firstNameTextBox.SetText += new UpdateControls.Forms.SetStringDelegate(this.firstNameTextBox_SetText);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name:";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(79, 29);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.RealTime = true;
            this.lastNameTextBox.Size = new System.Drawing.Size(167, 20);
            this.lastNameTextBox.TabIndex = 3;
            this.lastNameTextBox.GetText += new UpdateControls.Forms.GetStringDelegate(this.lastNameTextBox_GetText);
            this.lastNameTextBox.SetText += new UpdateControls.Forms.SetStringDelegate(this.lastNameTextBox_SetText);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Age:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Occupation:";
            // 
            // occupationComboBox
            // 
            this.occupationComboBox.FormattingEnabled = true;
            this.occupationComboBox.Location = new System.Drawing.Point(79, 81);
            this.occupationComboBox.Name = "occupationComboBox";
            this.occupationComboBox.Size = new System.Drawing.Size(121, 21);
            this.occupationComboBox.Sorted = true;
            this.occupationComboBox.TabIndex = 7;
            this.occupationComboBox.GetText += new UpdateControls.Forms.GetStringDelegate(this.occupationComboBox_GetText);
            this.occupationComboBox.SetText += new UpdateControls.Forms.SetStringDelegate(this.occupationComboBox_SetText);
            this.occupationComboBox.GetItems += new UpdateControls.Forms.GetCollectionDelegate(this.occupationComboBox_GetItems);
            // 
            // ageTextBox
            // 
            this.ageTextBox.Location = new System.Drawing.Point(79, 55);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.RealTime = true;
            this.ageTextBox.Size = new System.Drawing.Size(44, 20);
            this.ageTextBox.TabIndex = 5;
            this.ageTextBox.GetText += new UpdateControls.Forms.GetStringDelegate(this.ageTextBox_GetText);
            this.ageTextBox.SetText += new UpdateControls.Forms.SetStringDelegate(this.ageTextBox_SetText);
            // 
            // updateErrorProvider
            // 
            this.updateErrorProvider.ContainerControl = this;
            this.updateErrorProvider.Icon = ((System.Drawing.Icon)(resources.GetObject("updateErrorProvider.Icon")));
            // 
            // PersonControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.occupationComboBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ageTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.label1);
            this.Name = "PersonControl";
            this.Size = new System.Drawing.Size(256, 121);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private UpdateControls.Forms.UpdateTextBox firstNameTextBox;
        private System.Windows.Forms.Label label2;
        private UpdateControls.Forms.UpdateTextBox lastNameTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private UpdateControls.Forms.UpdateComboBox occupationComboBox;
        private UpdateControls.Forms.UpdateTextBox ageTextBox;
        private UpdateControls.Forms.UpdateErrorProvider updateErrorProvider;
    }
}
