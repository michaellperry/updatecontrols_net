using System;
using System.Collections.Generic;
using System.Text;

namespace CaseFile
{
    public class CaseFileException : Exception
    {
        public CaseFileException()
            : base() { }
        public CaseFileException(string message)
            : base(message) { }
        public CaseFileException(string message, Exception innerException)
            : base(message, innerException) { }
    }
}
