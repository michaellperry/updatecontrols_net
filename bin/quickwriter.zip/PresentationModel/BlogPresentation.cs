﻿using QuickWriter.DataModel;
using QuickWriter.NavigationModel;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using UpdateControls.XAML;

namespace QuickWriter.PresentationModel
{
	public class BlogPresentation
	{
		private Blog _blog;
		private BlogNavigation _navigation;

		public BlogPresentation(Blog blog, BlogNavigation navigation)
		{
			_blog = blog;
			_navigation = navigation;
		}

		public Blog Blog
		{
			get { return _blog; }
		}

		public BlogNavigation Navigation
		{
			get { return _navigation; }
		}

		public IEnumerable<Post> Posts
		{
			get
			{
                string selectedTopic = Navigation.SelectedTopic;
                if (selectedTopic == BlogNavigation.AllPosts)
                    return Blog.Posts;
                else
                    return Blog.Posts.Where(p => p.Topics.Any(t => t == selectedTopic));
			}
		}

		public ICommand NewPost
		{
			get
			{
				return MakeCommand
					.Do(() => Navigation.SelectedPost = Blog.NewPost());
			}
		}

		public ICommand DeletePost
		{
			get
			{
				return MakeCommand
					.When(() => Navigation.SelectedPost != null)
					.Do(() => Blog.DeletePost(Navigation.SelectedPost));
			}
		}

		public PostPresentation SelectedPostPresentation
		{
			get
			{
				if (Navigation.SelectedPost == null)
					return null;
				else
					return new PostPresentation(Navigation.SelectedPost, new PostNavigation());
			}
		}

        public IEnumerable<string> Topics
        {
            get
            {
                return new string[] { BlogNavigation.AllPosts }.Union(Blog.Topics);
            }
        }
	}
}
