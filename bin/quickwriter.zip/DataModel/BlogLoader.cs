﻿
namespace QuickWriter.DataModel
{
	public static class BlogLoader
	{
		public static Blog LoadBlog()
		{
			// Create a new blog.
			Blog blog = new Blog();

			// Initialize with test data.
			Post post;

			post = blog.NewPost();
			post.Title = "Data binding in WPF and Silverlight";
			post
				.AddTopic("WPF")
				.AddTopic("Silverlight");

			post = blog.NewPost();
			post.Title = "Interview with Jesse Liberty";
			post
				.AddTopic("Silverlight");

			post = blog.NewPost();
			post.Title = "More problems with Entity Framework, and how to fix them.";
			post
				.AddTopic("Entity Framework");

			post = blog.NewPost();
			post.Title = "Binding WPF forms to Entity Framework objects, and why you don't want to.";
			post
				.AddTopic("WPF")
				.AddTopic("Entity Framework");

			return blog;
		}
	}
}
