﻿using System.Windows;
using QuickWriter.DataModel;
using QuickWriter.NavigationModel;
using QuickWriter.PresentationModel;

namespace QuickWriter
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			this.DataContext = new BlogPresentation(BlogLoader.LoadBlog(), new BlogNavigation());
		}
	}
}
