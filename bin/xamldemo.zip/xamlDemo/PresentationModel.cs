﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace xamlDemo
{
	public class PresentationModel
	{
		private PersonList _personList;
		private NavigationModel _navigationModel;

		public PresentationModel(PersonList personList, NavigationModel navigationModel)
		{
			_personList = personList;
			_navigationModel = navigationModel;
		}

		public PersonList PersonList
		{
			get { return _personList; }
		}

		public NavigationModel NavigationModel
		{
			get { return _navigationModel; }
		}

		public string Title
		{
			get { return "People - " + (_navigationModel.SelectedPerson != null ? _navigationModel.SelectedPerson.Name : ""); }
		}
	}
}
