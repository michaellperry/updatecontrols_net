﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace xamlDemo
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		private PresentationModel _presentationModel;

		public Window1()
			: this(new PresentationModel(new PersonList(), new NavigationModel()))
		{
		}

		public Window1(PresentationModel presentationModel)
		{
			InitializeComponent();
			_presentationModel = presentationModel;
			DataContext = _presentationModel;
		}

		private void AddButton_Click(object sender, RoutedEventArgs e)
		{
			_presentationModel.NavigationModel.SelectedPerson = _presentationModel.PersonList.NewPerson();
		}

		private void DeleteButton_Click(object sender, RoutedEventArgs e)
		{
			if (_presentationModel.NavigationModel.SelectedPerson != null)
				_presentationModel.PersonList.DeletePerson(_presentationModel.NavigationModel.SelectedPerson);
		}

		private void NewWindow_Click(object sender, RoutedEventArgs e)
		{
			new Window1(new PresentationModel(_presentationModel.PersonList, new NavigationModel())).Show();
		}
	}
}
