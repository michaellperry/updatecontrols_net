﻿using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace Commuter
{
    public interface IPlaylist
    {
        string Name { get; }
    }

    public interface IPodcast
    {
        string Name { get; }
        bool Selected { get; set; }
        bool Rank1 { get; set; }
        bool Rank2 { get; set; }
        bool Rank3 { get; set; }
        bool Rank4 { get; set; }
        bool Rank5 { get; set; }
    }

    public interface IPodcastEpisode
    {
        string Name { get; }
        string PodcastName { get; }
        string DurationAsString { get; }
    }

    public interface ICommuterViewModel
    {
        IEnumerable<IPlaylist> Playlists { get; }
        IPlaylist SelectedPlaylist { get; set; }

        IEnumerable<IPodcast> Podcasts { get; }

        IEnumerable<IPodcastEpisode> Queue { get; }
        IPodcastEpisode SelectedEpisode { get; set; }
        string TotalDurationAsString { get; }

        ICommand Skip { get; }

        string LastSynchronizationError { get; }
    }
}
