﻿using System;
using System.Windows;
using UpdateControls.XAML;

namespace Commuter
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            // Create a view model for this commuter.
            App currentApp = Application.Current as App;
            if (currentApp != null)
                DataContext = ForView.Wrap(
                    new CommuterViewModel(
                        currentApp.MusicLibrary, 
                        currentApp.ITunesSynchronizationService, 
                        new CommuterNavigationModel()));
        }
    }
}
