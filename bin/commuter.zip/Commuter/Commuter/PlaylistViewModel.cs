using System;

namespace Commuter
{
    public class PlaylistViewModel : IPlaylist
    {
        private Playlist _playlist;

        public PlaylistViewModel(Playlist playlist)
        {
            _playlist = playlist;
        }

        public string Name
        {
            get { return _playlist.Name; }
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (obj == this)
                return true;
            if (obj.GetType() != this.GetType())
                return false;
            PlaylistViewModel that = (PlaylistViewModel)obj;
            return this._playlist == that._playlist;
        }

        public override int GetHashCode()
        {
          return _playlist.GetHashCode();
        }
    }
}
