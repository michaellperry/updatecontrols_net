using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;

namespace Commuter
{
    public class CommuterViewModel : ICommuterViewModel
    {
        private MusicLibrary _musicLibrary;
        private ITunesSynchronizationService _iTunesSynchronizationService;
        private CommuterNavigationModel _commuterNavigationModel;

        public CommuterViewModel(MusicLibrary musicLibrary, ITunesSynchronizationService iTunesSynchronizationService, CommuterNavigationModel commuterNavigationModel)
        {
            _musicLibrary = musicLibrary;
            _iTunesSynchronizationService = iTunesSynchronizationService;
            _commuterNavigationModel = commuterNavigationModel;
        }

        public IEnumerable<IPlaylist> Playlists
        {
            get { return _musicLibrary.Playlists.Select(p => new PlaylistViewModel(p) as IPlaylist); }
        }

        public IPlaylist SelectedPlaylist
        {
            get { return _commuterNavigationModel.SelectedPlaylist; }
            set { _commuterNavigationModel.SelectedPlaylist = value; }
        }

        public IEnumerable<IPodcast> Podcasts
        {
            get { return new List<IPodcast>(); }
        }

        public IEnumerable<IPodcastEpisode> Queue
        {
            get { return new List<IPodcastEpisode>(); }
        }

        public IPodcastEpisode SelectedEpisode
        {
            get { return null; }
            set { }
        }

        public string TotalDurationAsString
        {
            get { return string.Empty; }
        }

        public ICommand Skip
        {
            get { return null; }
        }

        public string LastSynchronizationError
        {
            get { return _iTunesSynchronizationService.LastError; }
        }
    }
}
