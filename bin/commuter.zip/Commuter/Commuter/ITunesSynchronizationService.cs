﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using iTunesLib;
using UpdateControls;

namespace Commuter
{
    public class ITunesSynchronizationService
    {
        private MusicLibrary _musicLibrary;
        private Thread _thread;
        private ManualResetEvent _stop;
        private bool _first = true;

        private string _lastError = string.Empty;
        private Independent _indLastError = new Independent();

        public ITunesSynchronizationService(MusicLibrary musicLibrary)
        {
            _musicLibrary = musicLibrary;
            _thread = new Thread(ThreadProc);
            _thread.Name = "iTunes synchronization service";
            _stop = new ManualResetEvent(false);
        }

        public void Start()
        {
            _thread.Start();
        }

        public void Stop()
        {
            _stop.Set();

            // Give it 30 seconds to shut down.
            _thread.Join(30000);
        }

        public string LastError
        {
            get
            {
                lock (this)
                {
                    _indLastError.OnGet();
                    return _lastError;
                }
            }

            private set
            {
                lock (this)
                {
                    _indLastError.OnSet();
                    _lastError = value;
                }
            }
        }

        private void ThreadProc()
        {
            while (ShouldContinue())
            {
                try
                {
                    // Connect to iTunes.
                    iTunesApp itApp = new iTunesAppClass();

                    // List all of the playlists.
                    List<Playlist> oldPlaylists = _musicLibrary.Playlists.ToList();
                    foreach (IITUserPlaylist itPlaylist in itApp.LibrarySource.Playlists.OfType<IITUserPlaylist>())
                    {
                        string name = itPlaylist.Name;
                        Playlist playlist = _musicLibrary.GetPlaylist(itPlaylist.playlistID);
                        if (name != null && playlist.Name != name)
                            playlist.Name = name;
                        oldPlaylists.Remove(playlist);
                    }

                    // Delete all that are no longer in iTunes.
                    foreach (Playlist playlist in oldPlaylists)
                        _musicLibrary.DeletePlaylist(playlist);

                    /*
                    foreach (IITTrack itTrack in itApp.LibraryPlaylist.Tracks)
                    {
                        if (itTrack.Genre == "Podcast")
                        {
                            // Find the existing podcast.
                            string podcastName = itTrack.Album;
                            var podcast = _podcasts.FirstOrDefault(p => p.Name == podcastName);
                            if (podcast == null)
                            {
                                podcast = new PodcastSubscription(podcastName);
                                _podcasts.Add(podcast);
                            }

                            podcast.NewEpisode(itTrack);
                        }
                    }
                     */

                    LastError = string.Empty;
                }
                catch (Exception ex)
                {
                    LastError = ex.Message;
                }
            }
        }
        private bool ShouldContinue()
        {
            // Don't wait the first time.
            if (_first)
            {
                _first = false;
                return true;
            }

            // Wake up every 10 seconds, or when the thread should stop.
            return !_stop.WaitOne(10000);
        }
    }
}
