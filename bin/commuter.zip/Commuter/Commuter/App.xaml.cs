﻿using System;
using System.Windows;

namespace Commuter
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private MusicLibrary _musicLibrary;
        private ITunesSynchronizationService _iTunesSynchronizationService;

        public MusicLibrary MusicLibrary
        {
            get { return _musicLibrary; }
        }

        public ITunesSynchronizationService ITunesSynchronizationService
        {
            get { return _iTunesSynchronizationService; }
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            // Create the music library.
            _musicLibrary = new MusicLibrary();

            // Start the iTunes synchronization service.
            _iTunesSynchronizationService = new ITunesSynchronizationService(_musicLibrary);
            _iTunesSynchronizationService.Start();
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            // Stop the iTunes synchronization service.
            _iTunesSynchronizationService.Stop();
        }
    }
}
